import { useState, useEffect } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Shield, Search, Download, Eye, Calendar, FileText, AlertTriangle, CheckCircle, Loader2 } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { exportVerificationToPDF } from "@/utils/pdfExport";

interface ScanRecord {
  id: string;
  document_type: string;
  status: string;
  result: any;
  created_at: string;
}

export default function ScanHistory() {
  const navigate = useNavigate();
  const { toast } = useToast();
  const [searchTerm, setSearchTerm] = useState("");
  const [filterType, setFilterType] = useState("all");
  const [filterStatus, setFilterStatus] = useState("all");
  const [scans, setScans] = useState<ScanRecord[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchScans();
  }, []);

  const fetchScans = async () => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) {
        navigate("/");
        return;
      }

      const { data, error } = await supabase.from('scans').select('*').eq('user_id', user.id).order('created_at', { ascending: false });
      if (error) throw error;
      setScans(data || []);
    } catch (error) {
      console.error('Error:', error);
      toast({ title: "Error", description: "Failed to load scan history", variant: "destructive" });
    } finally {
      setLoading(false);
    }
  };

  const filteredScans = scans.filter(scan => {
    const matchesSearch = scan.id.toLowerCase().includes(searchTerm.toLowerCase()) || scan.document_type.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesType = filterType === "all" || scan.document_type === filterType;
    const matchesStatus = filterStatus === "all" || scan.status === filterStatus;
    return matchesSearch && matchesType && matchesStatus;
  });

  const handleExport = (scan: ScanRecord) => {
    if (!scan.result) {
      toast({ title: "Error", description: "No data available to export", variant: "destructive" });
      return;
    }

    const documentTypeMap: { [key: string]: string } = {
      'visa': 'Visa',
      'passport': 'Passport',
      'boarding_pass': 'Boarding Pass',
      'business_authorization': 'Authorization Letter',
      'business_invitation': 'Invitation Letter',
      'biometric': 'Biometric Verification'
    };

    exportVerificationToPDF(scan.result, documentTypeMap[scan.document_type] || scan.document_type);
    toast({ title: "Success", description: "Report exported successfully" });
  };

  const getScoreFromResult = (result: any): number => {
    return result?.fraudScore || result?.tamperScore || 0;
  };

  const getScoreColor = (score: number) => {
    if (score >= 90) return "text-success";
    if (score >= 70) return "text-warning";
    return "text-destructive";
  };

  const getScoreBg = (score: number) => {
    if (score >= 90) return "bg-success/10";
    if (score >= 70) return "bg-warning/10";
    return "bg-destructive/10";
  };

  return (
    <div className="min-h-screen bg-background">
      <header className="bg-card border-b border-border shadow-soft sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-primary rounded-xl flex items-center justify-center">
                <Shield className="w-6 h-6 text-primary-foreground" />
              </div>
              <h1 className="text-xl font-bold">Scan History</h1>
            </div>
            <Button variant="outline" onClick={() => navigate("/dashboard")}>Back</Button>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8 max-w-7xl">
        <Card className="p-6 mb-6">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="md:col-span-2">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                <Input placeholder="Search by ID or document type..." value={searchTerm} onChange={(e) => setSearchTerm(e.target.value)} className="pl-9" />
              </div>
            </div>
            <Select value={filterType} onValueChange={setFilterType}>
              <SelectTrigger><SelectValue placeholder="Document Type" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Types</SelectItem>
                <SelectItem value="visa">Visa</SelectItem>
                <SelectItem value="passport">Passport</SelectItem>
                <SelectItem value="boarding_pass">Boarding Pass</SelectItem>
                <SelectItem value="business_authorization">Authorization</SelectItem>
                <SelectItem value="business_invitation">Invitation</SelectItem>
                <SelectItem value="biometric">Biometric</SelectItem>
              </SelectContent>
            </Select>
            <Select value={filterStatus} onValueChange={setFilterStatus}>
              <SelectTrigger><SelectValue placeholder="Status" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Statuses</SelectItem>
                <SelectItem value="completed">Completed</SelectItem>
                <SelectItem value="failed">Failed</SelectItem>
                <SelectItem value="processing">Processing</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </Card>

        {!loading && filteredScans.length > 0 && (
          <div className="mb-4 flex justify-between items-center">
            <p className="text-sm text-muted-foreground">
              Showing {filteredScans.length} of {scans.length} scans
            </p>
            <Button
              variant="outline"
              onClick={() => {
                filteredScans.forEach(scan => handleExport(scan));
                toast({ title: "Success", description: `Exported ${filteredScans.length} reports` });
              }}
              disabled={filteredScans.length === 0}
            >
              <Download className="w-4 h-4 mr-2" />
              Export All ({filteredScans.length})
            </Button>
          </div>
        )}

        {loading ? (
          <div className="flex justify-center py-12"><Loader2 className="w-8 h-8 animate-spin text-primary" /></div>
        ) : filteredScans.length === 0 ? (
          <Card className="p-12 text-center">
            <FileText className="w-16 h-16 mx-auto mb-4 text-muted-foreground" />
            <h3 className="text-xl font-semibold mb-2">No Scans Found</h3>
            <p className="text-muted-foreground mb-4">Start scanning documents to see your history</p>
            <Button onClick={() => navigate("/dashboard")}>Go to Dashboard</Button>
          </Card>
        ) : (
          <div className="space-y-4">
            {filteredScans.map((scan) => {
              const score = getScoreFromResult(scan.result);
              return (
                <Card key={scan.id} className="p-6 hover:shadow-lg transition-shadow">
                  <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                    <div className="flex items-center space-x-4">
                      <div className="w-12 h-12 bg-primary/10 rounded-xl flex items-center justify-center">
                        <FileText className="w-6 h-6 text-primary" />
                      </div>
                      <div>
                        <h3 className="font-semibold capitalize mb-1">
                          {scan.document_type.replace(/_/g, " ")}
                        </h3>
                        <div className="flex items-center space-x-2 text-sm text-muted-foreground">
                          <Calendar className="w-3 h-3" />
                          <span>{new Date(scan.created_at).toLocaleString()}</span>
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center gap-3">
                      {scan.result && (
                        <div className={`px-4 py-2 rounded-lg ${getScoreBg(score)}`}>
                          <div className="text-xs text-muted-foreground mb-1">Score</div>
                          <div className={`text-xl font-bold ${getScoreColor(score)}`}>
                            {score}/100
                          </div>
                        </div>
                      )}

                      <div className="flex items-center gap-2">
                        <Badge variant={scan.status === "completed" ? "default" : "destructive"}>
                          {scan.status === "completed" ? (
                            <><CheckCircle className="w-3 h-3 mr-1" /> {scan.status}</>
                          ) : (
                            <><AlertTriangle className="w-3 h-3 mr-1" /> {scan.status}</>
                          )}
                        </Badge>

                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleExport(scan)}
                          disabled={!scan.result}
                        >
                          <Download className="w-4 h-4 mr-1" />
                          Export PDF
                        </Button>
                      </div>
                    </div>
                  </div>
                </Card>
              );
            })}
          </div>
        )}
      </main>
    </div>
  );
}
