import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Shield, ArrowLeft, AlertTriangle, CheckCircle, Info, Bell } from "lucide-react";
import { Badge } from "@/components/ui/badge";

export default function Notifications() {
  const navigate = useNavigate();
  const [user, setUser] = useState<any>(null);

  const notifications = [
    {
      id: 1,
      type: "alert",
      title: "High Fraud Score Detected",
      message: "Passport #A9876543 has a fraud score of 92%. Immediate review required.",
      timestamp: "2 minutes ago",
      read: false,
    },
    {
      id: 2,
      type: "success",
      title: "Verification Complete",
      message: "Biometric verification for passenger John Doe completed successfully.",
      timestamp: "15 minutes ago",
      read: false,
    },
    {
      id: 3,
      type: "info",
      title: "System Update",
      message: "New fraud detection algorithms have been deployed to improve accuracy.",
      timestamp: "1 hour ago",
      read: true,
    },
    {
      id: 4,
      type: "alert",
      title: "Watchlist Match Found",
      message: "Potential match found in security database for document #V5544332.",
      timestamp: "2 hours ago",
      read: true,
    },
    {
      id: 5,
      type: "success",
      title: "Daily Report Ready",
      message: "Your daily verification summary is now available for review.",
      timestamp: "3 hours ago",
      read: true,
    },
  ];

  useEffect(() => {
    const userData = localStorage.getItem("visionpass_user");
    if (!userData) {
      navigate("/auth");
    } else {
      setUser(JSON.parse(userData));
    }
  }, [navigate]);

  const getNotificationIcon = (type: string) => {
    switch (type) {
      case "alert":
        return <AlertTriangle className="w-5 h-5 text-destructive" />;
      case "success":
        return <CheckCircle className="w-5 h-5 text-success" />;
      case "info":
        return <Info className="w-5 h-5 text-primary" />;
      default:
        return <Bell className="w-5 h-5 text-muted-foreground" />;
    }
  };

  const getNotificationBg = (type: string) => {
    switch (type) {
      case "alert":
        return "bg-destructive/10";
      case "success":
        return "bg-success/10";
      case "info":
        return "bg-primary/10";
      default:
        return "bg-muted";
    }
  };

  if (!user) return null;

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="bg-card border-b border-border shadow-soft sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <Button variant="ghost" size="icon" onClick={() => navigate("/dashboard")}>
                <ArrowLeft className="w-5 h-5" />
              </Button>
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 bg-primary rounded-xl flex items-center justify-center">
                  <Shield className="w-6 h-6 text-primary-foreground" />
                </div>
                <div>
                  <h1 className="text-xl font-bold">Notifications</h1>
                  <p className="text-xs text-muted-foreground">Stay updated on critical alerts</p>
                </div>
              </div>
            </div>
            <Button variant="outline">Mark All as Read</Button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8 max-w-4xl">
        <div className="space-y-4">
          {notifications.map((notification) => (
            <Card
              key={notification.id}
              className={`p-6 transition-all hover:shadow-soft ${
                !notification.read ? "border-primary/50 bg-primary/5" : ""
              }`}
            >
              <div className="flex items-start space-x-4">
                <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${getNotificationBg(notification.type)}`}>
                  {getNotificationIcon(notification.type)}
                </div>
                <div className="flex-1">
                  <div className="flex items-start justify-between mb-2">
                    <h3 className="font-bold">{notification.title}</h3>
                    {!notification.read && (
                      <Badge className="bg-primary text-primary-foreground">New</Badge>
                    )}
                  </div>
                  <p className="text-sm text-muted-foreground mb-2">{notification.message}</p>
                  <p className="text-xs text-muted-foreground">{notification.timestamp}</p>
                </div>
              </div>
            </Card>
          ))}
        </div>
      </main>
    </div>
  );
}
