import { Button } from "@/components/ui/button";
import { Shield, Scan, Camera, Search, CheckCircle, Lock, Zap, Award, Users, Building2, Globe, TrendingUp } from "lucide-react";
import { useNavigate } from "react-router-dom";

const Index = () => {
  const navigate = useNavigate();

  const features = [
    {
      icon: Scan,
      title: "AI Document Scanning",
      description: "Advanced passport and visa verification with fraud detection using machine learning",
    },
    {
      icon: Camera,
      title: "Biometric Verification",
      description: "Real-time facial recognition and liveness detection with 99.7% accuracy",
    },
    {
      icon: Search,
      title: "Watchlist Screening",
      description: "Instant database checks against global security watchlists",
    },
    {
      icon: Lock,
      title: "Tamper Detection",
      description: "Detect forged documents, fake signatures, and altered credentials",
    },
  ];

  const benefits = [
    {
      icon: Zap,
      title: "Lightning Fast",
      stat: "<2s",
      description: "Complete verification in under 2 seconds",
    },
    {
      icon: Award,
      title: "Highly Accurate",
      stat: "99.7%",
      description: "Industry-leading accuracy rate",
    },
    {
      icon: Shield,
      title: "Secure & Compliant",
      stat: "100%",
      description: "Full GDPR and security compliance",
    },
    {
      icon: Users,
      title: "Trusted Globally",
      stat: "1000+",
      description: "Organizations worldwide",
    },
  ];

  const industryLeaders = [
    { icon: Building2, name: "Government Agencies" },
    { icon: Globe, name: "International Airports" },
    { icon: Shield, name: "Border Security" },
    { icon: TrendingUp, name: "Immigration Services" },
  ];

  return (
    <div className="min-h-screen bg-background">
      {/* Navigation */}
      <nav className="border-b border-border/50 sticky top-0 z-50 bg-background/80 backdrop-blur-md">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-primary rounded-xl flex items-center justify-center shadow-soft">
                <Shield className="w-6 h-6 text-primary-foreground" />
              </div>
              <span className="text-xl font-bold">VisionPass AI</span>
            </div>
            <div className="flex items-center space-x-4">
              <Button variant="ghost" onClick={() => navigate("/auth")}>
                Sign In
              </Button>
              <Button className="gradient-primary text-white" onClick={() => navigate("/auth")}>
                Get Started
              </Button>
            </div>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative py-20 md:py-32 px-4 overflow-hidden">
        <div className="container mx-auto max-w-7xl relative z-10">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div className="space-y-8 animate-slide-up">
              <div className="inline-flex items-center space-x-2 px-4 py-2 bg-primary/10 border border-primary/20 rounded-full">
                <CheckCircle className="w-4 h-4 text-primary" />
                <span className="text-sm font-semibold text-primary">Trusted by 1000+ Organizations</span>
              </div>
              
              <div className="space-y-6">
                <h1 className="text-5xl md:text-7xl font-bold leading-tight text-foreground">
                  Next-Gen Document{" "}
                  <span className="text-primary">Verification</span>
                </h1>
                <p className="text-xl text-muted-foreground max-w-2xl leading-relaxed">
                  AI-powered passport, visa, and identity verification system designed for airports, 
                  border control, and immigration services worldwide.
                </p>
              </div>

              <div className="flex flex-col sm:flex-row gap-4">
                <Button size="lg" className="gradient-primary text-white shadow-medium" onClick={() => navigate("/auth")}>
                  Start Verification
                </Button>
                <Button size="lg" variant="outline">
                  Watch Demo
                </Button>
              </div>

              <div className="flex items-center gap-8 pt-6">
                <div>
                  <p className="text-3xl font-bold text-primary">99.7%</p>
                  <p className="text-sm text-muted-foreground">Accuracy</p>
                </div>
                <div className="h-12 w-px bg-border" />
                <div>
                  <p className="text-3xl font-bold text-primary">&lt;2s</p>
                  <p className="text-sm text-muted-foreground">Processing</p>
                </div>
                <div className="h-12 w-px bg-border" />
                <div>
                  <p className="text-3xl font-bold text-primary">1000+</p>
                  <p className="text-sm text-muted-foreground">Deployments</p>
                </div>
              </div>
            </div>

            <div className="relative animate-float">
              <div className="relative w-full aspect-square max-w-lg mx-auto">
                <div className="absolute inset-0 bg-primary/20 rounded-3xl blur-3xl" />
                <div className="relative bg-card border border-border rounded-3xl p-8 shadow-medium">
                  <div className="space-y-6">
                    <div className="flex items-center space-x-4">
                      <div className="w-12 h-12 bg-primary/10 rounded-xl flex items-center justify-center">
                        <Scan className="w-6 h-6 text-primary" />
                      </div>
                      <div>
                        <p className="font-semibold">Document Scanning</p>
                        <p className="text-sm text-muted-foreground">AI-powered analysis</p>
                      </div>
                    </div>
                    <div className="h-px bg-border" />
                    <div className="flex items-center space-x-4">
                      <div className="w-12 h-12 bg-primary/10 rounded-xl flex items-center justify-center">
                        <Camera className="w-6 h-6 text-primary" />
                      </div>
                      <div>
                        <p className="font-semibold">Biometric Matching</p>
                        <p className="text-sm text-muted-foreground">Face recognition</p>
                      </div>
                    </div>
                    <div className="h-px bg-border" />
                    <div className="flex items-center space-x-4">
                      <div className="w-12 h-12 bg-primary/10 rounded-xl flex items-center justify-center">
                        <Shield className="w-6 h-6 text-primary" />
                      </div>
                      <div>
                        <p className="font-semibold">Fraud Detection</p>
                        <p className="text-sm text-muted-foreground">Real-time analysis</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Trusted By Section */}
      <section className="py-16 px-4 bg-muted/30">
        <div className="container mx-auto max-w-7xl">
          <h3 className="text-center text-sm font-semibold text-muted-foreground mb-8">TRUSTED BY INDUSTRY LEADERS</h3>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {industryLeaders.map((leader, index) => (
              <div key={index} className="flex flex-col items-center justify-center space-y-3 p-6 rounded-xl bg-card border border-border hover:border-primary/50 transition-all shadow-soft">
                <div className="w-16 h-16 bg-primary/10 rounded-2xl flex items-center justify-center">
                  <leader.icon className="w-8 h-8 text-primary" />
                </div>
                <p className="text-sm font-semibold text-center">{leader.name}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 px-4">
        <div className="container mx-auto max-w-7xl">
          <div className="text-center mb-16 space-y-4">
            <h2 className="text-4xl md:text-5xl font-bold">Powerful Verification Features</h2>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              Advanced AI technology combined with industry best practices for comprehensive document verification
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {features.map((feature, index) => (
              <div 
                key={index} 
                className="p-6 rounded-2xl border border-border bg-card hover:border-primary/50 transition-all duration-300 hover:shadow-soft"
              >
                <div className="w-12 h-12 bg-primary/10 rounded-xl flex items-center justify-center mb-4">
                  <feature.icon className="w-6 h-6 text-primary" />
                </div>
                <h3 className="text-xl font-bold mb-2">{feature.title}</h3>
                <p className="text-muted-foreground">{feature.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Benefits Section */}
      <section className="py-20 px-4 bg-muted/30">
        <div className="container mx-auto max-w-7xl">
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {benefits.map((benefit, index) => (
              <div key={index} className="text-center p-8 rounded-2xl bg-card border border-border shadow-soft">
                <div className="w-16 h-16 bg-primary/10 rounded-2xl flex items-center justify-center mx-auto mb-4">
                  <benefit.icon className="w-8 h-8 text-primary" />
                </div>
                <div className="text-4xl font-bold text-primary mb-2">{benefit.stat}</div>
                <div className="font-bold mb-1">{benefit.title}</div>
                <p className="text-sm text-muted-foreground">{benefit.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 px-4">
        <div className="container mx-auto max-w-4xl">
          <div className="text-center p-12 rounded-3xl bg-primary/5 border border-primary/20">
            <h2 className="text-4xl font-bold mb-4">Ready to Get Started?</h2>
            <p className="text-xl text-muted-foreground mb-8">
              Join 1000+ organizations using VisionPass AI for secure document verification
            </p>
            <Button size="lg" className="gradient-primary text-white shadow-medium" onClick={() => navigate("/auth")}>
              Start Free Trial
            </Button>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-border py-12 px-4">
        <div className="container mx-auto max-w-7xl">
          <div className="flex flex-col md:flex-row justify-between items-center gap-4">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-primary rounded-xl flex items-center justify-center">
                <Shield className="w-6 h-6 text-primary-foreground" />
              </div>
              <span className="text-xl font-bold">VisionPass AI</span>
            </div>
            <p className="text-sm text-muted-foreground">
              © 2024 VisionPass AI. All rights reserved.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default Index;
