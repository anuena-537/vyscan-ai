import { Button } from "@/components/ui/button";
import { ArrowLeft } from "lucide-react";
import { useNavigate } from "react-router-dom";
import ScanHeader from "@/components/scan/ScanHeader";
import ScanMethodsGuide from "@/components/ScanMethodsGuide";

export default function ScanMethods() {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-background">
      <ScanHeader title="Ways to Scan" onBack={() => navigate("/dashboard")} />

      <main className="container mx-auto px-4 py-8 max-w-6xl">
        <ScanMethodsGuide />
      </main>
    </div>
  );
}
