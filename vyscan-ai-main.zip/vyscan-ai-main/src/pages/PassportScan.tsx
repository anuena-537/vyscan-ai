import { useState, useRef } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Shield, Upload, Camera, Scan, Fingerprint, Eye } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { useToast } from "@/hooks/use-toast";
import ScanHeader from "@/components/scan/ScanHeader";
import VerificationResults from "@/components/scan/VerificationResults";
import { supabase } from "@/integrations/supabase/client";
import { convertImageToBase64 } from "@/utils/imageUtils";

export default function PassportScan() {
  const navigate = useNavigate();
  const { toast } = useToast();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [scanning, setScanning] = useState(false);
  const [scanned, setScanned] = useState(false);
  const [results, setResults] = useState<any>(null);
  const [cameraActive, setCameraActive] = useState(false);
  const [stream, setStream] = useState<MediaStream | null>(null);

  const handleUploadClick = () => {
    fileInputRef.current?.click();
  };

  const startCamera = async () => {
    try {
      const mediaStream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: 'environment' },
        audio: false
      });
      
      if (videoRef.current) {
        videoRef.current.srcObject = mediaStream;
        setStream(mediaStream);
        setCameraActive(true);
        
        toast({
          title: "Camera Active",
          description: "Position the document in the frame and capture",
        });
      }
    } catch (error) {
      console.error('Camera permission error:', error);
      toast({
        title: "Camera Access Denied",
        description: "Please allow camera access to use this feature.",
        variant: "destructive",
      });
    }
  };

  const stopCamera = () => {
    if (stream) {
      stream.getTracks().forEach(track => track.stop());
      setStream(null);
      setCameraActive(false);
    }
  };

  const captureImage = async () => {
    if (!videoRef.current || !canvasRef.current) return;
    const video = videoRef.current;
    const canvas = canvasRef.current;
    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;
    
    const ctx = canvas.getContext('2d');
    if (ctx) {
      ctx.drawImage(video, 0, 0);
      canvas.toBlob(async (blob) => {
        if (blob) {
          const file = new File([blob], 'capture.jpg', { type: 'image/jpeg' });
          stopCamera();
          await processScan(file);
        }
      }, 'image/jpeg', 0.95);
    }
  };

  const handleScan = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;
    await processScan(file);
  };

  const processScan = async (file: File) => {
    setScanning(true);
    
    try {
      const imageData = await convertImageToBase64(file);
      const { data, error } = await supabase.functions.invoke('analyze-document', {
        body: { imageData, documentType: 'passport' }
      });

      if (error) {
        if (error.message?.includes('temporarily unavailable')) {
          toast({
            title: "Service Temporarily Unavailable",
            description: "AI analysis is currently unavailable. Please try again in a few moments.",
            variant: "destructive",
          });
        }
        throw error;
      }

      if (data.ocrFallback) {
        toast({
          title: "Limited Analysis",
          description: data.message || "Only basic text extraction was performed.",
        });
        
        setResults({
          fraudScore: 50,
          data: { extractedText: data.extractedText, note: "Manual review required" },
          security: {},
          warnings: data.warnings || [],
        });
        setScanned(true);
        return;
      }

      const processedResults = {
        fraudScore: data.fraudScore || 0,
        data: {
          name: data.fullName || "N/A",
          nationality: data.nationality || "N/A",
          passportNumber: data.documentNumber || "N/A",
          dateOfBirth: data.dateOfBirth || "N/A",
          expiryDate: data.expiryDate || "N/A",
          issueDate: data.issueDate || "N/A",
        },
        security: {},
        warnings: data.warnings || [],
      };

      if (data.securityFeatures) {
        data.securityFeatures.forEach((feature: any) => {
          processedResults.security[feature.name] = {
            status: feature.status,
            confidence: feature.confidence
          };
        });
      }

      setResults(processedResults);
      setScanned(true);
      
      toast({
        title: "Scan Complete",
        description: `Fraud score: ${processedResults.fraudScore}/100`,
      });

      const { data: { user } } = await supabase.auth.getUser();
      if (user) {
        await supabase.from('scans').insert({
          user_id: user.id,
          document_type: 'passport',
          status: 'completed',
          result: processedResults
        });
      }
    } catch (error) {
      console.error('Scan error:', error);
      toast({
        title: "Scan Failed",
        description: "Failed to analyze document. Please try again.",
        variant: "destructive",
      });
    } finally {
      setScanning(false);
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <ScanHeader title="Passport Scanner" onBack={() => navigate("/dashboard")} />
      <main className="container mx-auto px-4 py-8 max-w-6xl">
        {!scanned ? (
          <div className="space-y-8 animate-slide-up">
            <Card className="relative overflow-hidden border-border/50 shadow-large">
              <div className="relative p-12 text-center">
                <div className="w-24 h-24 bg-primary rounded-3xl flex items-center justify-center mx-auto mb-6 shadow-medium">
                  <Shield className="w-12 h-12 text-primary-foreground" />
                </div>
                <h2 className="text-3xl font-bold mb-3">Advanced Passport Verification</h2>
                <p className="text-muted-foreground text-lg mb-8 max-w-2xl mx-auto">
                  AI-powered document analysis with biometric verification
                </p>
                <input ref={fileInputRef} type="file" accept="image/*" className="hidden" onChange={handleScan} disabled={scanning} />
                <div className="flex flex-col sm:flex-row gap-4 justify-center mb-8">
                  <Button size="lg" className="w-full sm:w-auto" disabled={scanning || cameraActive} onClick={handleUploadClick}>
                    <Upload className="mr-2 w-5 h-5" />{scanning ? "Analyzing..." : "Upload"}
                  </Button>
                  <Button size="lg" variant="outline" className="w-full sm:w-auto" onClick={cameraActive ? stopCamera : startCamera} disabled={scanning}>
                    <Camera className="mr-2 w-5 h-5" />{cameraActive ? "Stop" : "Camera"}
                  </Button>
                </div>
                {cameraActive && (
                  <div className="mt-6 mb-8">
                    <video ref={videoRef} autoPlay playsInline className="w-full max-w-2xl mx-auto rounded-lg border-2 border-primary" />
                    <canvas ref={canvasRef} className="hidden" />
                    <Button size="lg" className="mt-4" onClick={captureImage} disabled={scanning}>
                      <Camera className="w-5 h-5 mr-2" />Capture
                    </Button>
                  </div>
                )}
              </div>
            </Card>
            {scanning && (
              <Card className="p-12">
                <div className="text-center">
                  <h3 className="text-2xl font-bold mb-3">Analyzing...</h3>
                  <p className="text-muted-foreground">This may take a few moments</p>
                </div>
              </Card>
            )}
          </div>
        ) : (
          <VerificationResults results={results} type="passport" onNewScan={() => setScanned(false)} />
        )}
      </main>
    </div>
  );
}
