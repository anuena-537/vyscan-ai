import { useState } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Search, AlertTriangle, CheckCircle, Shield, Database, Lock } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { useToast } from "@/hooks/use-toast";
import ScanHeader from "@/components/scan/ScanHeader";

export default function WatchlistCheck() {
  const navigate = useNavigate();
  const { toast } = useToast();
  const [searching, setSearching] = useState(false);
  const [searched, setSearched] = useState(false);
  const [passportNumber, setPassportNumber] = useState("");
  const [name, setName] = useState("");
  const [alerts, setAlerts] = useState<any[]>([]);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    setSearching(true);
    
    setTimeout(() => {
      setSearching(false);
      setSearched(true);
      
      // Mock alerts (10% chance of alert)
      const hasAlert = Math.random() < 0.1;
      
      if (hasAlert) {
        setAlerts([
          {
            type: "warning",
            database: "International Criminal Database",
            reason: "Name similarity match - requires verification",
            confidence: 75,
          }
        ]);
        toast({
          title: "Alert Found",
          description: "Manual review required",
          variant: "destructive",
        });
      } else {
        setAlerts([]);
        toast({
          title: "No Matches Found",
          description: "Traveler cleared for entry",
        });
      }
    }, 2000);
  };

  return (
    <div className="min-h-screen bg-background">
      <ScanHeader title="Watchlist Check" onBack={() => navigate("/dashboard")} />

      <main className="container mx-auto px-4 py-8 max-w-6xl">
        <div className="space-y-8 animate-slide-up">
          <Card className="relative overflow-hidden border-border/50 shadow-large">
            <div className="relative p-12">
              <div className="text-center mb-8">
                <div className="w-24 h-24 bg-gradient-to-br from-warning via-destructive to-warning rounded-3xl flex items-center justify-center mx-auto mb-6 shadow-[0_0_40px_rgba(234,179,8,0.3)] animate-pulse-glow">
                  <Shield className="w-12 h-12 text-primary-foreground" />
                </div>
                <h2 className="text-3xl font-bold mb-3 bg-gradient-to-r from-warning to-destructive bg-clip-text text-transparent">
                  Global Security Database
                </h2>
                <p className="text-muted-foreground text-lg mb-4">
                  Real-time screening against international watchlists, Interpol databases, and security alerts
                </p>
              </div>

              <form onSubmit={handleSearch} className="space-y-6 max-w-xl mx-auto mb-8">
                <div className="relative group">
                  <div className="absolute -inset-0.5 bg-gradient-to-r from-warning to-destructive rounded-xl opacity-30 group-hover:opacity-50 blur transition duration-300"></div>
                  <div className="relative space-y-2 p-6 bg-card/80 backdrop-blur-sm rounded-xl border border-border/50">
                    <Label htmlFor="name" className="text-base">Full Legal Name</Label>
                    <Input
                      id="name"
                      placeholder="Enter full name as appears on passport"
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      required
                      className="h-12 text-base"
                    />
                  </div>
                </div>

                <div className="relative group">
                  <div className="absolute -inset-0.5 bg-gradient-to-r from-warning to-destructive rounded-xl opacity-30 group-hover:opacity-50 blur transition duration-300"></div>
                  <div className="relative space-y-2 p-6 bg-card/80 backdrop-blur-sm rounded-xl border border-border/50">
                    <Label htmlFor="passport" className="text-base">Passport Number</Label>
                    <Input
                      id="passport"
                      placeholder="Enter passport number"
                      value={passportNumber}
                      onChange={(e) => setPassportNumber(e.target.value)}
                      required
                      className="h-12 text-base"
                    />
                  </div>
                </div>

                <Button type="submit" className="w-full text-base" size="lg" disabled={searching}>
                  <Search className="mr-2 w-5 h-5" />
                  {searching ? "Searching Databases..." : "Search Security Databases"}
                </Button>
              </form>

              <div className="grid grid-cols-3 gap-6 max-w-3xl mx-auto">
                <div className="flex flex-col items-center p-4 rounded-xl bg-card/50 backdrop-blur-sm border border-border/50">
                  <Database className="w-8 h-8 text-warning mb-2" />
                  <p className="text-sm font-medium">50+ Databases</p>
                </div>
                <div className="flex flex-col items-center p-4 rounded-xl bg-card/50 backdrop-blur-sm border border-border/50">
                  <Lock className="w-8 h-8 text-destructive mb-2" />
                  <p className="text-sm font-medium">Encrypted Search</p>
                </div>
                <div className="flex flex-col items-center p-4 rounded-xl bg-card/50 backdrop-blur-sm border border-border/50">
                  <Search className="w-8 h-8 text-info mb-2" />
                  <p className="text-sm font-medium">Real-Time Check</p>
                </div>
              </div>
            </div>
          </Card>

          {searching && (
            <Card className="p-12 gradient-card shadow-large border-border/50 relative overflow-hidden">
              <div className="absolute inset-0 bg-gradient-to-r from-warning/5 via-destructive/5 to-warning/5 animate-gradient"></div>
              <div className="relative text-center">
                <div className="w-20 h-20 mx-auto mb-6 relative">
                  <div className="absolute inset-0 border-4 border-warning/30 rounded-full"></div>
                  <div className="absolute inset-0 border-4 border-warning border-t-transparent rounded-full animate-spin"></div>
                </div>
                <h3 className="text-2xl font-bold mb-3">Searching International Databases</h3>
                <p className="text-muted-foreground text-lg mb-6">
                  Checking against Interpol, security watchlists, and criminal databases
                </p>
                <div className="flex flex-col space-y-3 max-w-md mx-auto">
                  <div className="flex items-center justify-between p-3 rounded-lg bg-card/50 backdrop-blur-sm">
                    <span className="text-sm">Interpol Database</span>
                    <div className="w-6 h-6 border-2 border-success border-t-transparent rounded-full animate-spin"></div>
                  </div>
                  <div className="flex items-center justify-between p-3 rounded-lg bg-card/50 backdrop-blur-sm">
                    <span className="text-sm">Security Watchlists</span>
                    <div className="w-6 h-6 border-2 border-warning border-t-transparent rounded-full animate-spin"></div>
                  </div>
                  <div className="flex items-center justify-between p-3 rounded-lg bg-card/50 backdrop-blur-sm">
                    <span className="text-sm">Travel Restrictions</span>
                    <div className="w-6 h-6 border-2 border-info border-t-transparent rounded-full animate-spin"></div>
                  </div>
                </div>
              </div>
            </Card>
          )}

          {searched && alerts.length === 0 && (
            <Card className="p-12 gradient-card shadow-large border-border/50">
              <div className="text-center">
                <div className="w-24 h-24 bg-success/20 rounded-full flex items-center justify-center mx-auto mb-6 shadow-[0_0_40px_rgba(34,197,94,0.4)]">
                  <CheckCircle className="w-12 h-12 text-success" />
                </div>
                <h3 className="text-3xl font-bold mb-3 text-success">No Matches Found</h3>
                <p className="text-muted-foreground text-lg mb-6">Traveler has been cleared for entry</p>
                <div className="grid md:grid-cols-3 gap-6 max-w-2xl mx-auto mb-8">
                  <div className="p-6 rounded-xl bg-success/5 border border-success/20">
                    <p className="text-2xl font-bold text-success mb-2">52</p>
                    <p className="text-sm text-muted-foreground">Databases Checked</p>
                  </div>
                  <div className="p-6 rounded-xl bg-success/5 border border-success/20">
                    <p className="text-2xl font-bold text-success mb-2">0</p>
                    <p className="text-sm text-muted-foreground">Alerts Found</p>
                  </div>
                  <div className="p-6 rounded-xl bg-success/5 border border-success/20">
                    <p className="text-2xl font-bold text-success mb-2">&lt;1s</p>
                    <p className="text-sm text-muted-foreground">Search Time</p>
                  </div>
                </div>
                <Button size="lg" variant="outline" onClick={() => setSearched(false)}>Search Another Traveler</Button>
              </div>
            </Card>
          )}

          {searched && alerts.length > 0 && (
            <Card className="p-12 gradient-card shadow-large border-border/50">
              <div className="text-center">
                <div className="w-24 h-24 bg-destructive/20 rounded-full flex items-center justify-center mx-auto mb-6 shadow-[0_0_40px_rgba(239,68,68,0.4)]">
                  <AlertTriangle className="w-12 h-12 text-destructive" />
                </div>
                <h3 className="text-3xl font-bold mb-3 text-destructive">Alert Detected</h3>
                <p className="text-muted-foreground text-lg mb-8">Manual review and verification required</p>
                <div className="space-y-4 max-w-2xl mx-auto mb-6">
                  {alerts.map((alert, index) => (
                    <div key={index} className="p-6 rounded-xl bg-destructive/5 border border-destructive/20 text-left">
                      <div className="flex items-start justify-between mb-3">
                        <div>
                          <p className="font-semibold text-lg mb-1">{alert.database}</p>
                          <p className="text-sm text-muted-foreground">{alert.reason}</p>
                        </div>
                        <div className="text-right">
                          <p className="text-2xl font-bold text-destructive">{alert.confidence}%</p>
                          <p className="text-xs text-muted-foreground">Match</p>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
                <Button size="lg" variant="outline" onClick={() => setSearched(false)}>Search Another Traveler</Button>
              </div>
            </Card>
          )}
        </div>
      </main>
    </div>
  );
}
