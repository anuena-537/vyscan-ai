import { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ArrowLeft, TrendingUp, CheckCircle, XCircle, FileText } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { LineChart, Line, AreaChart, Area, BarChart, Bar, PieChart, Pie, Cell, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from "recharts";
import { format, subDays, startOfDay } from "date-fns";

interface ScanData {
  date: string;
  total: number;
  completed: number;
  failed: number;
  successRate: number;
}

interface DocumentTypeData {
  type: string;
  count: number;
  percentage: number;
}

const COLORS = ['hsl(var(--primary))', 'hsl(var(--info))', 'hsl(var(--warning))', 'hsl(var(--success))', 'hsl(var(--destructive))', 'hsl(var(--muted))'];

export default function Statistics() {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [timeRange, setTimeRange] = useState(30);
  const [trendData, setTrendData] = useState<ScanData[]>([]);
  const [documentTypeData, setDocumentTypeData] = useState<DocumentTypeData[]>([]);
  const [overallStats, setOverallStats] = useState({
    totalScans: 0,
    successRate: 0,
    avgPerDay: 0,
    mostCommonType: ""
  });

  useEffect(() => {
    fetchStatistics();
  }, [timeRange]);

  const fetchStatistics = async () => {
    try {
      setLoading(true);
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) {
        navigate("/");
        return;
      }

      const startDate = startOfDay(subDays(new Date(), timeRange));

      const { data: scans, error } = await supabase
        .from('scans')
        .select('*')
        .eq('user_id', user.id)
        .gte('created_at', startDate.toISOString())
        .order('created_at', { ascending: true });

      if (error) throw error;

      // Process trend data
      const dateMap = new Map<string, { total: number; completed: number; failed: number }>();
      
      for (let i = 0; i < timeRange; i++) {
        const date = format(subDays(new Date(), timeRange - i - 1), 'MMM dd');
        dateMap.set(date, { total: 0, completed: 0, failed: 0 });
      }

      scans?.forEach(scan => {
        const date = format(new Date(scan.created_at), 'MMM dd');
        const existing = dateMap.get(date);
        if (existing) {
          existing.total += 1;
          if (scan.status === 'completed') existing.completed += 1;
          if (scan.status === 'failed') existing.failed += 1;
          dateMap.set(date, existing);
        }
      });

      const trend = Array.from(dateMap.entries()).map(([date, stats]) => ({
        date,
        total: stats.total,
        completed: stats.completed,
        failed: stats.failed,
        successRate: stats.total > 0 ? Math.round((stats.completed / stats.total) * 100) : 0
      }));

      setTrendData(trend);

      // Process document type data
      const typeMap = new Map<string, number>();
      scans?.forEach(scan => {
        const type = scan.document_type;
        typeMap.set(type, (typeMap.get(type) || 0) + 1);
      });

      const totalDocs = scans?.length || 0;
      const docTypes = Array.from(typeMap.entries()).map(([type, count]) => ({
        type: type.replace(/_/g, ' ').toUpperCase(),
        count,
        percentage: totalDocs > 0 ? Math.round((count / totalDocs) * 100) : 0
      })).sort((a, b) => b.count - a.count);

      setDocumentTypeData(docTypes);

      // Calculate overall stats
      const completedCount = scans?.filter(s => s.status === 'completed').length || 0;
      const successRate = totalDocs > 0 ? Math.round((completedCount / totalDocs) * 100) : 0;
      const avgPerDay = totalDocs > 0 ? (totalDocs / timeRange).toFixed(1) : '0';
      const mostCommonType = docTypes[0]?.type || 'N/A';

      setOverallStats({
        totalScans: totalDocs,
        successRate,
        avgPerDay: parseFloat(avgPerDay),
        mostCommonType
      });

    } catch (error) {
      console.error('Error fetching statistics:', error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <header className="bg-card border-b border-border shadow-soft sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center space-x-4">
            <Button variant="ghost" size="icon" onClick={() => navigate("/dashboard")}>
              <ArrowLeft className="w-5 h-5" />
            </Button>
            <div>
              <h1 className="text-2xl font-bold">Statistics & Analytics</h1>
              <p className="text-sm text-muted-foreground">Track your scan performance over time</p>
            </div>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        {/* Time Range Selector */}
        <div className="flex gap-2 mb-6">
          <Button variant={timeRange === 7 ? "default" : "outline"} onClick={() => setTimeRange(7)}>7 Days</Button>
          <Button variant={timeRange === 30 ? "default" : "outline"} onClick={() => setTimeRange(30)}>30 Days</Button>
          <Button variant={timeRange === 90 ? "default" : "outline"} onClick={() => setTimeRange(90)}>90 Days</Button>
        </div>

        {/* Overview Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardHeader className="pb-3">
              <CardDescription>Total Scans</CardDescription>
              <CardTitle className="text-3xl">{overallStats.totalScans}</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center text-sm text-muted-foreground">
                <FileText className="w-4 h-4 mr-1" />
                Last {timeRange} days
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-3">
              <CardDescription>Success Rate</CardDescription>
              <CardTitle className="text-3xl">{overallStats.successRate}%</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center text-sm text-success">
                <CheckCircle className="w-4 h-4 mr-1" />
                {overallStats.successRate >= 80 ? 'Excellent' : overallStats.successRate >= 60 ? 'Good' : 'Needs improvement'}
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-3">
              <CardDescription>Avg. Per Day</CardDescription>
              <CardTitle className="text-3xl">{overallStats.avgPerDay}</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center text-sm text-muted-foreground">
                <TrendingUp className="w-4 h-4 mr-1" />
                Daily average
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-3">
              <CardDescription>Most Common</CardDescription>
              <CardTitle className="text-xl">{overallStats.mostCommonType}</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center text-sm text-muted-foreground">
                <FileText className="w-4 h-4 mr-1" />
                Document type
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Charts */}
        {loading ? (
          <div className="text-center py-12 text-muted-foreground">Loading statistics...</div>
        ) : trendData.length === 0 ? (
          <Card className="p-12 text-center">
            <p className="text-muted-foreground">No scan data available for the selected time period</p>
          </Card>
        ) : (
          <div className="space-y-6">
            {/* Scan Trends Over Time */}
            <Card>
              <CardHeader>
                <CardTitle>Scan Trends Over Time</CardTitle>
                <CardDescription>Total scans completed and failed per day</CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <AreaChart data={trendData}>
                    <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                    <XAxis dataKey="date" stroke="hsl(var(--muted-foreground))" />
                    <YAxis stroke="hsl(var(--muted-foreground))" />
                    <Tooltip 
                      contentStyle={{ 
                        backgroundColor: 'hsl(var(--card))', 
                        border: '1px solid hsl(var(--border))',
                        borderRadius: '8px'
                      }}
                    />
                    <Legend />
                    <Area type="monotone" dataKey="completed" stackId="1" stroke="hsl(var(--success))" fill="hsl(var(--success) / 0.6)" name="Completed" />
                    <Area type="monotone" dataKey="failed" stackId="1" stroke="hsl(var(--destructive))" fill="hsl(var(--destructive) / 0.6)" name="Failed" />
                  </AreaChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            {/* Success Rate Trend */}
            <Card>
              <CardHeader>
                <CardTitle>Success Rate Trend</CardTitle>
                <CardDescription>Percentage of successful scans over time</CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <LineChart data={trendData}>
                    <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                    <XAxis dataKey="date" stroke="hsl(var(--muted-foreground))" />
                    <YAxis stroke="hsl(var(--muted-foreground))" domain={[0, 100]} />
                    <Tooltip 
                      contentStyle={{ 
                        backgroundColor: 'hsl(var(--card))', 
                        border: '1px solid hsl(var(--border))',
                        borderRadius: '8px'
                      }}
                      formatter={(value: number) => `${value}%`}
                    />
                    <Legend />
                    <Line type="monotone" dataKey="successRate" stroke="hsl(var(--primary))" strokeWidth={3} name="Success Rate (%)" />
                  </LineChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Document Type Breakdown */}
              <Card>
                <CardHeader>
                  <CardTitle>Document Type Distribution</CardTitle>
                  <CardDescription>Breakdown by document type</CardDescription>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={300}>
                    <PieChart>
                      <Pie
                        data={documentTypeData}
                        cx="50%"
                        cy="50%"
                        labelLine={false}
                        label={({ type, percentage }) => `${type}: ${percentage}%`}
                        outerRadius={100}
                        fill="hsl(var(--primary))"
                        dataKey="count"
                      >
                        {documentTypeData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                        ))}
                      </Pie>
                      <Tooltip 
                        contentStyle={{ 
                          backgroundColor: 'hsl(var(--card))', 
                          border: '1px solid hsl(var(--border))',
                          borderRadius: '8px'
                        }}
                      />
                    </PieChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>

              {/* Document Type Bar Chart */}
              <Card>
                <CardHeader>
                  <CardTitle>Document Type Counts</CardTitle>
                  <CardDescription>Total scans per document type</CardDescription>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={300}>
                    <BarChart data={documentTypeData}>
                      <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                      <XAxis dataKey="type" stroke="hsl(var(--muted-foreground))" angle={-45} textAnchor="end" height={100} />
                      <YAxis stroke="hsl(var(--muted-foreground))" />
                      <Tooltip 
                        contentStyle={{ 
                          backgroundColor: 'hsl(var(--card))', 
                          border: '1px solid hsl(var(--border))',
                          borderRadius: '8px'
                        }}
                      />
                      <Bar dataKey="count" fill="hsl(var(--primary))" />
                    </BarChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>
            </div>
          </div>
        )}
      </main>
    </div>
  );
}
