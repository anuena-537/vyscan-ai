import { useState, useRef } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Upload, Camera, FileText, Plane, Building, Scan } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { useToast } from "@/hooks/use-toast";
import ScanHeader from "@/components/scan/ScanHeader";
import BusinessDocResults from "@/components/scan/BusinessDocResults";
import { supabase } from "@/integrations/supabase/client";
import { convertImageToBase64 } from "@/utils/imageUtils";

type DocumentType = "boarding" | "authorization" | "invitation" | null;

export default function BusinessDocScan() {
  const navigate = useNavigate();
  const { toast } = useToast();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [selectedType, setSelectedType] = useState<DocumentType>(null);
  const [scanning, setScanning] = useState(false);
  const [scanned, setScanned] = useState(false);
  const [results, setResults] = useState<any>(null);

  const handleUploadClick = () => {
    fileInputRef.current?.click();
  };

  const documentTypes = [
    {
      id: "boarding" as DocumentType,
      icon: Plane,
      title: "Boarding Pass",
      description: "Airline boarding pass verification",
      color: "bg-primary/10 text-primary",
    },
    {
      id: "authorization" as DocumentType,
      icon: Building,
      title: "Authorization Letter",
      description: "Company authorization document",
      color: "bg-accent/10 text-accent",
    },
    {
      id: "invitation" as DocumentType,
      icon: FileText,
      title: "Invitation Letter",
      description: "Business invitation verification",
      color: "bg-info/10 text-info",
    },
  ];

  const handleScan = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    if (!selectedType) {
      toast({
        title: "Select Document Type",
        description: "Please choose a document type first",
        variant: "destructive",
      });
      return;
    }

    setScanning(true);

    try {
      const imageData = await convertImageToBase64(file);
      
      const { data, error } = await supabase.functions.invoke('analyze-document', {
        body: { imageData, documentType: selectedType }
      });

      if (error) throw error;

      const processedResults = {
        tamperScore: data.tamperScore || 0,
        documentType: selectedType === 'boarding' ? 'Boarding Pass' : 
                     selectedType === 'authorization' ? 'Company Authorization Letter' : 
                     'Business Invitation Letter',
        data: {},
        tamperChecks: {},
        warnings: data.warnings || [],
      };

      // Map Gemini response to expected format based on document type
      if (selectedType === 'boarding') {
        processedResults.data = {
          passengerName: data.passengerName || "N/A",
          flightNumber: data.flightNumber || "N/A",
          from: data.departure || "N/A",
          to: data.arrival || "N/A",
          date: data.date || "N/A",
          time: data.time || "N/A",
          seat: data.seat || "N/A",
        };
      } else if (selectedType === 'authorization') {
        processedResults.data = {
          authorizedPerson: data.authorizedPerson || "N/A",
          authorizerName: data.authorizerName || "N/A",
          purpose: data.purpose || "N/A",
          validFrom: data.validFrom || "N/A",
          validUntil: data.validUntil || "N/A",
        };
      } else if (selectedType === 'invitation') {
        processedResults.data = {
          guestName: data.guestName || "N/A",
          hostName: data.hostName || "N/A",
          purpose: data.purpose || "N/A",
          eventDate: data.eventDate || "N/A",
          venue: data.venue || "N/A",
        };
      }

      setResults(processedResults);
      setScanned(true);

      toast({
        title: "Scan Complete",
        description: `Document analysis finished - Score: ${processedResults.tamperScore}/100`,
      });
    } catch (error) {
      console.error('Scan error:', error);
      toast({
        title: "Scan Failed",
        description: "Failed to analyze document. Please try again.",
        variant: "destructive",
      });
    } finally {
      setScanning(false);
    }
  };

  const generateMockResults = (type: DocumentType) => {
    const baseScore = Math.floor(Math.random() * 30) + 70;
    
    const commonChecks = {
      fontConsistency: { status: baseScore > 85 ? "verified" : "warning", confidence: Math.floor(Math.random() * 10) + 90 },
      paperTexture: { status: "verified", confidence: Math.floor(Math.random() * 10) + 88 },
      printQuality: { status: "verified", confidence: Math.floor(Math.random() * 10) + 92 },
      digitalForensics: { status: baseScore > 80 ? "verified" : "warning", confidence: Math.floor(Math.random() * 15) + 85 },
    };

    switch (type) {
      case "boarding":
        return {
          tamperScore: baseScore,
          documentType: "Boarding Pass",
          data: {
            passengerName: "SMITH/JOHN MR",
            flightNumber: "BA123",
            airline: "British Airways",
            from: "London Heathrow (LHR)",
            to: "New York JFK (JFK)",
            date: "2024-02-15",
            seat: "12A",
            gate: "B42",
            boardingTime: "10:45",
            bookingReference: "ABC123",
            frequent: "BA Gold - 123456789",
          },
          tamperChecks: {
            ...commonChecks,
            barcodeValidity: { status: "verified", confidence: 99 },
            airlineLogoAuth: { status: "verified", confidence: 97 },
            qrCodeIntegrity: { status: "verified", confidence: 98 },
            timestampVerify: { status: "verified", confidence: 96 },
          },
          warnings: baseScore < 85 ? ["Font inconsistency detected in passenger name field"] : [],
        };

      case "authorization":
        return {
          tamperScore: baseScore,
          documentType: "Company Authorization Letter",
          data: {
            companyName: "Tech Solutions Inc.",
            authorizedPerson: "John Smith",
            purpose: "Business Travel to USA",
            validFrom: "2024-01-15",
            validUntil: "2024-12-31",
            signatoryName: "Jane Doe",
            signatoryTitle: "CEO",
            companyStamp: "Present",
            referenceNumber: "AUTH-2024-001234",
          },
          tamperChecks: {
            ...commonChecks,
            signatureAuthenticity: { status: baseScore > 82 ? "verified" : "warning", confidence: Math.floor(Math.random() * 15) + 80 },
            companyStampCheck: { status: "verified", confidence: 94 },
            letterheadVerify: { status: "verified", confidence: 96 },
            dateConsistency: { status: "verified", confidence: 98 },
            metadataAnalysis: { status: "verified", confidence: 91 },
          },
          warnings: baseScore < 85 ? ["Signature appears digitally altered", "Company stamp resolution inconsistency"] : [],
        };

      case "invitation":
        return {
          tamperScore: baseScore,
          documentType: "Business Invitation Letter",
          data: {
            invitingCompany: "Global Business Corp",
            invitedPerson: "John Smith",
            visitPurpose: "Business Conference & Meetings",
            visitDuration: "Jan 15 - Jan 25, 2024",
            hostName: "Michael Johnson",
            hostTitle: "Director of Operations",
            companyAddress: "123 Business Ave, London, UK",
            contactNumber: "+44 20 1234 5678",
            referenceNumber: "INV-2024-5678",
          },
          tamperChecks: {
            ...commonChecks,
            signatureMatch: { status: "verified", confidence: 93 },
            companyVerification: { status: "verified", confidence: 95 },
            letterheadAuth: { status: "verified", confidence: 97 },
            contactVerify: { status: baseScore > 83 ? "verified" : "warning", confidence: 89 },
            formatConsistency: { status: "verified", confidence: 92 },
          },
          warnings: baseScore < 85 ? ["Date format inconsistency detected", "Contact details require verification"] : [],
        };

      default:
        return null;
    }
  };

  const resetScan = () => {
    setScanned(false);
    setSelectedType(null);
    setResults(null);
  };

  return (
    <div className="min-h-screen bg-background">
      <ScanHeader title="Business Documents Scanner" onBack={() => navigate("/dashboard")} />

      <main className="container mx-auto px-4 py-8 max-w-6xl">
        {!scanned ? (
          <div className="space-y-6 animate-slide-up">
            {/* Document Type Selection */}
            {!selectedType && (
              <Card className="p-8 gradient-card shadow-soft border-border/50">
                <div className="text-center mb-6">
                  <div className="w-20 h-20 bg-primary/10 rounded-2xl flex items-center justify-center mx-auto mb-4">
                    <FileText className="w-10 h-10 text-primary" />
                  </div>
                  <h2 className="text-2xl font-bold mb-2">Select Document Type</h2>
                  <p className="text-muted-foreground">
                    Choose the type of business document to verify
                  </p>
                </div>

                <div className="grid md:grid-cols-3 gap-6">
                  {documentTypes.map((type) => (
                    <button
                      key={type.id}
                      onClick={() => setSelectedType(type.id)}
                      className="group p-6 rounded-2xl border-2 border-border hover:border-primary transition-all duration-300 bg-card hover:shadow-medium"
                    >
                      <div className={`w-16 h-16 rounded-xl flex items-center justify-center mx-auto mb-4 ${type.color} group-hover:scale-110 transition-transform`}>
                        <type.icon className="w-8 h-8" />
                      </div>
                      <h3 className="text-lg font-semibold mb-2">{type.title}</h3>
                      <p className="text-sm text-muted-foreground">{type.description}</p>
                    </button>
                  ))}
                </div>
              </Card>
            )}

            {/* Upload Area */}
            {selectedType && (
              <>
                <Card className="p-8 gradient-card shadow-soft border-border/50">
                  <div className="text-center">
                    <div className="flex items-center justify-between mb-6">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => setSelectedType(null)}
                      >
                        ← Change Type
                      </Button>
                      <div className="flex items-center space-x-2">
                        {documentTypes.find(t => t.id === selectedType)?.icon && (
                          <>
                            {(() => {
                              const Icon = documentTypes.find(t => t.id === selectedType)!.icon;
                              return <Icon className="w-5 h-5 text-primary" />;
                            })()}
                          </>
                        )}
                        <span className="font-semibold">
                          {documentTypes.find(t => t.id === selectedType)?.title}
                        </span>
                      </div>
                    </div>

                    <div className="w-20 h-20 bg-primary/10 rounded-2xl flex items-center justify-center mx-auto mb-4">
                      <FileText className="w-10 h-10 text-primary" />
                    </div>
                    <h2 className="text-2xl font-bold mb-2">Upload Document</h2>
                    <p className="text-muted-foreground mb-6">
                      Upload a clear image or use camera to scan the document
                    </p>

                    <input 
                      ref={fileInputRef}
                      type="file" 
                      accept="image/*" 
                      className="hidden" 
                      onChange={handleScan} 
                      disabled={scanning} 
                    />
                    
                    <div className="flex flex-col sm:flex-row gap-4 justify-center">
                      <Button 
                        size="lg" 
                        className="w-full sm:w-auto px-8" 
                        disabled={scanning}
                        onClick={handleUploadClick}
                      >
                        <Upload className="mr-2 w-5 h-5" />
                        {scanning ? "Analyzing..." : "Upload Document"}
                      </Button>
                      <Button 
                        size="lg" 
                        variant="outline"
                        className="w-full sm:w-auto text-base px-8" 
                        disabled
                      >
                        <Camera className="mr-2 w-5 h-5" />
                        Connect Camera
                      </Button>
                      <Button 
                        size="lg" 
                        variant="outline"
                        className="w-full sm:w-auto text-base px-8" 
                        disabled
                      >
                        <Scan className="mr-2 w-5 h-5" />
                        Connect Scanner
                      </Button>
                    </div>
                  </div>
                </Card>

                {/* Scanning Animation */}
                {scanning && (
                  <Card className="p-8 shadow-soft border-border/50 bg-card">
                    <div className="text-center">
                      <div className="w-16 h-16 border-4 border-primary border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
                      <h3 className="text-xl font-semibold mb-2">Analyzing Document...</h3>
                      <p className="text-muted-foreground">
                        Checking authenticity, detecting tampering, and verifying signatures
                      </p>
                    </div>
                  </Card>
                )}

                {/* Tamper Detection Info */}
                <div className="grid md:grid-cols-3 gap-6">
                  <Card className="p-6 shadow-soft border-border/50 bg-card">
                    <div className="w-12 h-12 bg-primary/10 rounded-xl flex items-center justify-center mb-4">
                      <FileText className="w-6 h-6 text-primary" />
                    </div>
                    <h3 className="font-semibold mb-2">Font Analysis</h3>
                    <p className="text-sm text-muted-foreground">
                      Detect font inconsistencies and digital alterations
                    </p>
                  </Card>
                  <Card className="p-6 shadow-soft border-border/50 bg-card">
                    <div className="w-12 h-12 bg-primary/10 rounded-xl flex items-center justify-center mb-4">
                      <Building className="w-6 h-6 text-accent" />
                    </div>
                    <h3 className="font-semibold mb-2">Signature Verify</h3>
                    <p className="text-sm text-muted-foreground">
                      Authenticate signatures and company stamps
                    </p>
                  </Card>
                  <Card className="p-6 shadow-soft border-border/50 bg-card">
                    <div className="w-12 h-12 bg-primary/10 rounded-xl flex items-center justify-center mb-4">
                      <Plane className="w-6 h-6 text-primary" />
                    </div>
                    <h3 className="font-semibold mb-2">Metadata Check</h3>
                    <p className="text-sm text-muted-foreground">
                      Analyze document metadata and creation history
                    </p>
                  </Card>
                </div>
              </>
            )}
          </div>
        ) : (
          <BusinessDocResults results={results} onNewScan={resetScan} />
        )}
      </main>
    </div>
  );
}
