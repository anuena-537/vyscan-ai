import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Shield, ArrowLeft, Download, Search, Filter } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";

export default function AuditLog() {
  const navigate = useNavigate();
  const { toast } = useToast();
  const [user, setUser] = useState<any>(null);
  const [searchTerm, setSearchTerm] = useState("");

  const auditLogs = [
    {
      id: 1,
      timestamp: "2024-01-20 14:35:22",
      user: "Officer Smith",
      action: "Passport Scan",
      details: "Verified passport #A1234567",
      status: "success",
      fraudScore: 2,
    },
    {
      id: 2,
      timestamp: "2024-01-20 14:32:15",
      user: "Officer Johnson",
      action: "Biometric Verification",
      details: "Facial recognition match confirmed",
      status: "success",
      fraudScore: 5,
    },
    {
      id: 3,
      timestamp: "2024-01-20 14:28:44",
      user: "Officer Smith",
      action: "Visa Check",
      details: "Detected expired visa #V9876543",
      status: "warning",
      fraudScore: 65,
    },
    {
      id: 4,
      timestamp: "2024-01-20 14:25:33",
      user: "Officer Davis",
      action: "Watchlist Check",
      details: "No matches found in security database",
      status: "success",
      fraudScore: 0,
    },
    {
      id: 5,
      timestamp: "2024-01-20 14:20:11",
      user: "Officer Johnson",
      action: "Document Scan",
      details: "Suspected forged document detected",
      status: "error",
      fraudScore: 92,
    },
    {
      id: 6,
      timestamp: "2024-01-20 14:15:07",
      user: "Officer Smith",
      action: "Passport Scan",
      details: "Valid travel document verified",
      status: "success",
      fraudScore: 3,
    },
  ];

  useEffect(() => {
    const userData = localStorage.getItem("visionpass_user");
    if (!userData) {
      navigate("/auth");
    } else {
      setUser(JSON.parse(userData));
    }
  }, [navigate]);

  const exportLogs = () => {
    const csv = [
      ["Timestamp", "User", "Action", "Details", "Status", "Fraud Score"],
      ...auditLogs.map((log) => [
        log.timestamp,
        log.user,
        log.action,
        log.details,
        log.status,
        log.fraudScore,
      ]),
    ]
      .map((row) => row.join(","))
      .join("\n");

    const blob = new Blob([csv], { type: "text/csv" });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `audit-log-${new Date().toISOString()}.csv`;
    a.click();

    toast({
      title: "Export successful",
      description: "Audit log has been exported to CSV.",
    });
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "success":
        return "bg-success/10 text-success border-success/20";
      case "warning":
        return "bg-warning/10 text-warning border-warning/20";
      case "error":
        return "bg-destructive/10 text-destructive border-destructive/20";
      default:
        return "bg-muted text-muted-foreground";
    }
  };

  const getFraudScoreColor = (score: number) => {
    if (score >= 70) return "text-destructive";
    if (score >= 40) return "text-warning";
    return "text-success";
  };

  const filteredLogs = auditLogs.filter(
    (log) =>
      log.user.toLowerCase().includes(searchTerm.toLowerCase()) ||
      log.action.toLowerCase().includes(searchTerm.toLowerCase()) ||
      log.details.toLowerCase().includes(searchTerm.toLowerCase())
  );

  if (!user) return null;

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="bg-card border-b border-border shadow-soft sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <Button variant="ghost" size="icon" onClick={() => navigate("/dashboard")}>
                <ArrowLeft className="w-5 h-5" />
              </Button>
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 bg-primary rounded-xl flex items-center justify-center">
                  <Shield className="w-6 h-6 text-primary-foreground" />
                </div>
                <div>
                  <h1 className="text-xl font-bold">Audit Log</h1>
                  <p className="text-xs text-muted-foreground">Track verification activities</p>
                </div>
              </div>
            </div>
            <Button onClick={exportLogs} className="bg-primary text-primary-foreground">
              <Download className="w-4 h-4 mr-2" />
              Export CSV
            </Button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8">
        {/* Filters */}
        <Card className="p-6 mb-6">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <Input
                placeholder="Search by user, action, or details..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
            <Button variant="outline">
              <Filter className="w-4 h-4 mr-2" />
              Filter
            </Button>
          </div>
        </Card>

        {/* Audit Log Table */}
        <Card className="p-6">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-border">
                  <th className="text-left py-3 px-4 font-semibold text-sm">Timestamp</th>
                  <th className="text-left py-3 px-4 font-semibold text-sm">User</th>
                  <th className="text-left py-3 px-4 font-semibold text-sm">Action</th>
                  <th className="text-left py-3 px-4 font-semibold text-sm">Details</th>
                  <th className="text-left py-3 px-4 font-semibold text-sm">Fraud Score</th>
                  <th className="text-left py-3 px-4 font-semibold text-sm">Status</th>
                </tr>
              </thead>
              <tbody>
                {filteredLogs.map((log) => (
                  <tr key={log.id} className="border-b border-border hover:bg-muted/50 transition-colors">
                    <td className="py-4 px-4 text-sm font-mono">{log.timestamp}</td>
                    <td className="py-4 px-4 text-sm">{log.user}</td>
                    <td className="py-4 px-4 text-sm font-medium">{log.action}</td>
                    <td className="py-4 px-4 text-sm text-muted-foreground">{log.details}</td>
                    <td className="py-4 px-4 text-sm">
                      <span className={`font-semibold ${getFraudScoreColor(log.fraudScore)}`}>
                        {log.fraudScore}%
                      </span>
                    </td>
                    <td className="py-4 px-4">
                      <Badge className={getStatusColor(log.status)}>{log.status}</Badge>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </Card>
      </main>
    </div>
  );
}
