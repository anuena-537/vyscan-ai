import { useState } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Camera, Upload, UserCheck, Scan as ScanIcon, Target, Zap } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { useToast } from "@/hooks/use-toast";
import ScanHeader from "@/components/scan/ScanHeader";
import { supabase } from "@/integrations/supabase/client";
import { convertImageToBase64 } from "@/utils/imageUtils";

export default function BiometricVerification() {
  const navigate = useNavigate();
  const { toast } = useToast();
  const [scanning, setScanning] = useState(false);
  const [verified, setVerified] = useState(false);
  const [matchScore, setMatchScore] = useState(0);
  const [documentImage, setDocumentImage] = useState<string | null>(null);
  const [liveImage, setLiveImage] = useState<string | null>(null);

  const handleDocumentUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;
    const base64 = await convertImageToBase64(file);
    setDocumentImage(base64);
  };

  const handleLiveUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;
    const base64 = await convertImageToBase64(file);
    setLiveImage(base64);
  };

  const handleVerify = async () => {
    if (!documentImage || !liveImage) {
      toast({
        title: "Missing Images",
        description: "Please upload both document and live photos",
        variant: "destructive",
      });
      return;
    }

    setScanning(true);
    
    try {
      const { data, error } = await supabase.functions.invoke('analyze-document', {
        body: { 
          imageData: `${documentImage}|||${liveImage}`, 
          documentType: 'biometric' 
        }
      });

      if (error) throw error;

      const score = data.matchScore || 0;
      setMatchScore(score);
      setVerified(true);
      
      toast({
        title: score >= 90 ? "Biometric Match" : "Verification Complete",
        description: `Match confidence: ${score}%`,
      });
    } catch (error) {
      console.error('Verification error:', error);
      toast({
        title: "Verification Failed",
        description: "Failed to verify biometric match. Please try again.",
        variant: "destructive",
      });
    } finally {
      setScanning(false);
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <ScanHeader title="Biometric Verification" onBack={() => navigate("/dashboard")} />

      <main className="container mx-auto px-4 py-8 max-w-6xl">
        <div className="space-y-8 animate-slide-up">
          {!verified ? (
            <>
              <Card className="relative overflow-hidden border-border/50 shadow-large">
                <div className="relative p-12">
                  <div className="text-center mb-8">
                    <div className="w-24 h-24 bg-primary rounded-3xl flex items-center justify-center mx-auto mb-6 shadow-medium">
                      <UserCheck className="w-12 h-12 text-primary-foreground" />
                    </div>
                    <h2 className="text-3xl font-bold mb-3 text-foreground">
                      Advanced Facial Recognition
                    </h2>
                    <p className="text-muted-foreground text-lg mb-4">
                      AI-powered biometric matching with liveness detection and 3D depth analysis
                    </p>
                  </div>

                  <div className="grid md:grid-cols-2 gap-8 mb-8 max-w-4xl mx-auto">
                    <div className="relative group">
                      <div className="relative p-8 bg-card/80 backdrop-blur-sm rounded-2xl border border-border/50">
                        <div className="flex items-center justify-between mb-4">
                          <p className="text-sm font-semibold">Passport Photo</p>
                          <ScanIcon className="w-5 h-5 text-primary" />
                        </div>
                        <label className="cursor-pointer block">
                          <input type="file" accept="image/*" className="hidden" onChange={handleDocumentUpload} />
                          <div className="w-full h-64 bg-muted/50 rounded-xl flex flex-col items-center justify-center hover:bg-muted/70 transition-all duration-300 border-2 border-dashed border-border hover:border-primary group-hover:scale-[1.02]">
                            <Upload className="w-12 h-12 text-muted-foreground mb-3" />
                            <p className="text-sm text-muted-foreground">
                              {documentImage ? "Document uploaded ✓" : "Upload document photo"}
                            </p>
                          </div>
                        </label>
                      </div>
                    </div>

                    <div className="relative group">
                      <div className="relative p-8 bg-card/80 backdrop-blur-sm rounded-2xl border border-border/50">
                        <div className="flex items-center justify-between mb-4">
                          <p className="text-sm font-semibold">Live Capture</p>
                          <Camera className="w-5 h-5 text-accent" />
                        </div>
                        <label className="cursor-pointer block">
                          <input type="file" accept="image/*" className="hidden" onChange={handleLiveUpload} />
                          <div className="w-full h-64 bg-muted/50 rounded-xl flex flex-col items-center justify-center hover:bg-muted/70 transition-all duration-300 border-2 border-dashed border-border hover:border-accent group-hover:scale-[1.02]">
                            <Camera className="w-12 h-12 text-muted-foreground mb-3" />
                            <p className="text-sm text-muted-foreground">
                              {liveImage ? "Live photo captured ✓" : "Capture live photo"}
                            </p>
                          </div>
                        </label>
                      </div>
                    </div>
                  </div>

                  <div className="text-center">
                    <div className="flex flex-col sm:flex-row gap-4 justify-center mb-8">
                      <Button size="lg" onClick={handleVerify} disabled={scanning} className="text-base px-12">
                        {scanning ? "Processing..." : "Verify Identity"}
                        <Zap className="ml-2 w-5 h-5" />
                      </Button>
                      <Button 
                        size="lg" 
                        variant="outline"
                        className="w-full sm:w-auto text-base px-8" 
                        disabled
                      >
                        <Camera className="mr-2 w-5 h-5" />
                        Connect Camera
                      </Button>
                      <Button 
                        size="lg" 
                        variant="outline"
                        className="w-full sm:w-auto text-base px-8" 
                        disabled
                      >
                        <ScanIcon className="mr-2 w-5 h-5" />
                        Connect Scanner
                      </Button>
                    </div>
                  </div>

                  <div className="grid grid-cols-3 gap-6 max-w-3xl mx-auto mt-8">
                    <div className="flex flex-col items-center p-4 rounded-xl bg-card/50 backdrop-blur-sm border border-border/50">
                      <Target className="w-8 h-8 text-success mb-2" />
                      <p className="text-sm font-medium">Facial Landmarks</p>
                    </div>
                    <div className="flex flex-col items-center p-4 rounded-xl bg-card/50 backdrop-blur-sm border border-border/50">
                      <UserCheck className="w-8 h-8 text-info mb-2" />
                      <p className="text-sm font-medium">Liveness Check</p>
                    </div>
                    <div className="flex flex-col items-center p-4 rounded-xl bg-card/50 backdrop-blur-sm border border-border/50">
                      <Zap className="w-8 h-8 text-warning mb-2" />
                      <p className="text-sm font-medium">AI Matching</p>
                    </div>
                  </div>
                </div>
              </Card>

              {scanning && (
                <Card className="p-12 gradient-card shadow-large border-border/50 relative overflow-hidden">
                  <div className="absolute inset-0 bg-gradient-to-r from-info/5 via-accent/5 to-info/5 animate-gradient"></div>
                  <div className="relative text-center">
                    <div className="w-20 h-20 mx-auto mb-6 relative">
                      <div className="absolute inset-0 border-4 border-primary/30 rounded-full"></div>
                      <div className="absolute inset-0 border-4 border-primary border-t-transparent rounded-full animate-spin"></div>
                    </div>
                    <h3 className="text-2xl font-bold mb-3">Analyzing Biometric Data</h3>
                    <p className="text-muted-foreground text-lg">
                      Performing facial analysis and liveness verification
                    </p>
                  </div>
                </Card>
              )}
            </>
          ) : (
            <Card className="p-12 gradient-card shadow-large border-border/50 relative overflow-hidden">
              <div className="absolute inset-0 opacity-5">
                <div className="absolute inset-0 bg-gradient-to-br from-success via-info to-accent animate-gradient"></div>
              </div>
              <div className="relative text-center">
                <div className={`inline-flex items-center justify-center w-32 h-32 rounded-full mb-6 ${
                  matchScore >= 90 ? "bg-success/20 shadow-[0_0_40px_rgba(34,197,94,0.4)]" : "bg-warning/20 shadow-[0_0_40px_rgba(234,179,8,0.4)]"
                }`}>
                  <div className="text-center">
                    <div className={`text-5xl font-bold ${matchScore >= 90 ? "text-success" : "text-warning"}`}>
                      {matchScore}%
                    </div>
                  </div>
                </div>
                <h2 className="text-3xl font-bold mb-3">
                  {matchScore >= 90 ? "Identity Verified" : "Manual Review Required"}
                </h2>
                <p className="text-muted-foreground text-lg mb-8">
                  {matchScore >= 90 
                    ? "Biometric features match with high confidence" 
                    : "Additional verification may be needed"}
                </p>
                
                <div className="grid md:grid-cols-4 gap-6 max-w-3xl mx-auto mb-8">
                  <div className="p-6 rounded-xl bg-card/50 backdrop-blur-sm border border-border/50">
                    <p className="text-3xl font-bold text-success mb-2">98%</p>
                    <p className="text-sm text-muted-foreground">Face Match</p>
                  </div>
                  <div className="p-6 rounded-xl bg-card/50 backdrop-blur-sm border border-border/50">
                    <p className="text-3xl font-bold text-success mb-2">96%</p>
                    <p className="text-sm text-muted-foreground">Liveness</p>
                  </div>
                  <div className="p-6 rounded-xl bg-card/50 backdrop-blur-sm border border-border/50">
                    <p className="text-3xl font-bold text-success mb-2">94%</p>
                    <p className="text-sm text-muted-foreground">Quality</p>
                  </div>
                  <div className="p-6 rounded-xl bg-card/50 backdrop-blur-sm border border-border/50">
                    <p className="text-3xl font-bold text-info mb-2">100%</p>
                    <p className="text-sm text-muted-foreground">Confidence</p>
                  </div>
                </div>

                <Button size="lg" variant="outline" onClick={() => setVerified(false)}>
                  Verify Another Person
                </Button>
              </div>
            </Card>
          )}
        </div>
      </main>
    </div>
  );
}
