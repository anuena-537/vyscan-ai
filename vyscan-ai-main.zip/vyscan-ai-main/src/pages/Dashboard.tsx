import { useState, useEffect } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Shield, Scan, AlertTriangle, FileCheck, LogOut, History as HistoryIcon, Settings, Bell, Users, TrendingUp, BarChart3 } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import StatsCard from "@/components/dashboard/StatsCard";
import RecentActivity from "@/components/dashboard/RecentActivity";
import QuickActions from "@/components/dashboard/QuickActions";
import AnalyticsChart from "@/components/dashboard/AnalyticsChart";
import FlaggedDocuments from "@/components/dashboard/FlaggedDocuments";
import ArticlesSection from "@/components/dashboard/ArticlesSection";
import { Badge } from "@/components/ui/badge";

interface ScanStats {
  total: number;
  completed: number;
  failed: number;
  processing: number;
  byType: Record<string, number>;
}

export default function Dashboard() {
  const navigate = useNavigate();
  const { toast } = useToast();
  const [user, setUser] = useState<any>(null);
  const [stats, setStats] = useState<ScanStats>({
    total: 0,
    completed: 0,
    failed: 0,
    processing: 0,
    byType: {}
  });
  const [flaggedDocs, setFlaggedDocs] = useState<any[]>([]);

  useEffect(() => {
    checkAuth();
    fetchStats();
    fetchFlaggedDocuments();
  }, []);

  const checkAuth = async () => {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) {
      navigate("/");
    } else {
      setUser(user);
    }
  };

  const fetchStats = async () => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      const { data: scans, error } = await supabase
        .from('scans')
        .select('*')
        .eq('user_id', user.id);

      if (error) throw error;

      const newStats: ScanStats = {
        total: scans?.length || 0,
        completed: scans?.filter(s => s.status === 'completed').length || 0,
        failed: scans?.filter(s => s.status === 'failed').length || 0,
        processing: scans?.filter(s => s.status === 'processing').length || 0,
        byType: {}
      };

      scans?.forEach(scan => {
        const type = scan.document_type;
        newStats.byType[type] = (newStats.byType[type] || 0) + 1;
      });

      setStats(newStats);
    } catch (error) {
      console.error('Error fetching stats:', error);
    }
  };

  const fetchFlaggedDocuments = async () => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      const { data: scans, error } = await supabase
        .from('scans')
        .select('*')
        .eq('user_id', user.id)
        .eq('status', 'completed')
        .order('created_at', { ascending: false });

      if (error) throw error;

      // Filter for flagged documents (high fraud/tamper scores or suspected fakes)
      const flagged = scans?.filter(scan => {
        const result = scan.result as any;
        const fraudScore = result?.fraudScore || result?.tamperScore || 0;
        const warnings = result?.warnings || [];
        const isSuspected = warnings.some((w: string) => w.includes("SUSPECTED FAKE"));
        return fraudScore >= 70 || isSuspected;
      }) || [];

      setFlaggedDocs(flagged);
    } catch (error) {
      console.error('Error fetching flagged documents:', error);
    }
  };

  const handleLogout = async () => {
    await supabase.auth.signOut();
    navigate("/");
  };

  if (!user) return null;

  return (
    <div className="min-h-screen bg-background">
      <header className="bg-card border-b border-border shadow-soft sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-primary rounded-xl flex items-center justify-center">
                <Shield className="w-6 h-6 text-primary-foreground" />
              </div>
              <div>
                <h1 className="text-xl font-bold">Vyscan</h1>
                <p className="text-xs text-muted-foreground">Automating visa checks</p>
              </div>
            </div>
            <div className="flex items-center space-x-2">
              <div className="hidden md:flex items-center space-x-1 mr-2">
                <Button variant="ghost" size="sm" onClick={() => navigate("/scan/methods")}>
                  <FileCheck className="w-4 h-4 mr-2" />
                  Ways to Scan
                </Button>
                <Button variant="ghost" size="sm" onClick={() => navigate("/statistics")}>
                  <BarChart3 className="w-4 h-4 mr-2" />
                  Statistics
                </Button>
                <Button variant="ghost" size="sm" onClick={() => navigate("/scan-history")}>
                  <HistoryIcon className="w-4 h-4 mr-2" />
                  History
                </Button>
                <Button variant="ghost" size="sm" onClick={() => navigate("/team-collaboration")}>
                  <Users className="w-4 h-4 mr-2" />
                  Team
                </Button>
                <Button variant="ghost" size="sm" onClick={() => navigate("/notifications")}>
                  <Bell className="w-4 h-4 mr-2" />
                  Notifications
                </Button>
                <Button variant="ghost" size="sm" onClick={() => navigate("/settings")}>
                  <Settings className="w-4 h-4 mr-2" />
                  Settings
                </Button>
              </div>
              <div className="hidden md:flex items-center space-x-2 px-3 py-1 bg-muted rounded-lg">
                <p className="text-sm font-medium">{user.email}</p>
                <Badge variant="secondary" className="text-xs">Pro</Badge>
              </div>
              <Button variant="outline" size="icon" className="md:hidden" onClick={() => navigate("/scan-history")}>
                <HistoryIcon className="w-4 h-4" />
              </Button>
              <Button variant="outline" size="icon" className="md:hidden" onClick={() => navigate("/settings")}>
                <Settings className="w-4 h-4" />
              </Button>
              <Button variant="outline" size="icon" onClick={handleLogout}>
                <LogOut className="w-4 h-4" />
              </Button>
            </div>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        <div className="mb-8">
          <h2 className="text-3xl font-bold mb-2">Welcome back!</h2>
          <p className="text-muted-foreground">Here's your verification dashboard</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <StatsCard icon={Scan} title="Total Scans" value={stats.total.toString()} trend="+12.3%" trendUp={true} color="primary" />
          <StatsCard icon={FileCheck} title="Completed" value={stats.completed.toString()} trend={`${stats.total > 0 ? Math.round((stats.completed / stats.total) * 100) : 0}%`} trendUp={true} color="info" />
          <StatsCard icon={AlertTriangle} title="Flagged" value={stats.failed.toString()} trend={stats.failed > 0 ? `${stats.failed} flagged` : "No issues"} trendUp={false} color="destructive" />
          <StatsCard icon={TrendingUp} title="Processing" value={stats.processing.toString()} trend="In progress" trendUp={true} color="warning" />
        </div>

        <div className="mb-8">
          <QuickActions />
        </div>

        {flaggedDocs.length > 0 && (
          <div className="mb-8">
            <FlaggedDocuments flaggedDocs={flaggedDocs} />
          </div>
        )}

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
          <div className="lg:col-span-2">
            <AnalyticsChart stats={stats} />
          </div>
          <div>
            <RecentActivity />
          </div>
        </div>

        <ArticlesSection />
      </main>
    </div>
  );
}
