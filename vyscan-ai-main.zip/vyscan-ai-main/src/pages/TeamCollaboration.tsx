import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Shield, ArrowLeft, UserPlus, CheckCircle, XCircle, Clock } from "lucide-react";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";

export default function TeamCollaboration() {
  const navigate = useNavigate();
  const [user, setUser] = useState<any>(null);

  const pendingReviews = [
    {
      id: 1,
      document: "Passport #A7654321",
      submittedBy: "Officer Smith",
      timestamp: "2024-01-20 15:30:00",
      fraudScore: 45,
      status: "pending",
      votes: { approve: 1, reject: 0 },
    },
    {
      id: 2,
      document: "Visa #V1122334",
      submittedBy: "Officer Johnson",
      timestamp: "2024-01-20 15:25:00",
      fraudScore: 72,
      status: "pending",
      votes: { approve: 0, reject: 2 },
    },
    {
      id: 3,
      document: "Business Permit #BP9988",
      submittedBy: "Officer Davis",
      timestamp: "2024-01-20 15:20:00",
      fraudScore: 38,
      status: "pending",
      votes: { approve: 2, reject: 1 },
    },
  ];

  const teamMembers = [
    { name: "Officer Smith", role: "Senior Verifier", status: "online", initials: "OS" },
    { name: "Officer Johnson", role: "Document Analyst", status: "online", initials: "OJ" },
    { name: "Officer Davis", role: "Security Lead", status: "away", initials: "OD" },
    { name: "Officer Martinez", role: "Biometric Specialist", status: "offline", initials: "OM" },
  ];

  useEffect(() => {
    const userData = localStorage.getItem("visionpass_user");
    if (!userData) {
      navigate("/auth");
    } else {
      setUser(JSON.parse(userData));
    }
  }, [navigate]);

  const getStatusColor = (status: string) => {
    switch (status) {
      case "online":
        return "bg-success";
      case "away":
        return "bg-warning";
      case "offline":
        return "bg-muted";
      default:
        return "bg-muted";
    }
  };

  const getFraudScoreColor = (score: number) => {
    if (score >= 70) return "text-destructive";
    if (score >= 40) return "text-warning";
    return "text-success";
  };

  if (!user) return null;

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="bg-card border-b border-border shadow-soft sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <Button variant="ghost" size="icon" onClick={() => navigate("/dashboard")}>
                <ArrowLeft className="w-5 h-5" />
              </Button>
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 bg-primary rounded-xl flex items-center justify-center">
                  <Shield className="w-6 h-6 text-primary-foreground" />
                </div>
                <div>
                  <h1 className="text-xl font-bold">Team Collaboration</h1>
                  <p className="text-xs text-muted-foreground">Review and approve verifications together</p>
                </div>
              </div>
            </div>
            <Button className="bg-primary text-primary-foreground">
              <UserPlus className="w-4 h-4 mr-2" />
              Invite Member
            </Button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8">
        <div className="grid lg:grid-cols-3 gap-6">
          {/* Pending Reviews */}
          <div className="lg:col-span-2 space-y-6">
            <h2 className="text-2xl font-bold">Pending Reviews</h2>
            {pendingReviews.map((review) => (
              <Card key={review.id} className="p-6">
                <div className="space-y-4">
                  <div className="flex items-start justify-between">
                    <div>
                      <h3 className="font-bold text-lg">{review.document}</h3>
                      <p className="text-sm text-muted-foreground">
                        Submitted by {review.submittedBy}
                      </p>
                      <p className="text-xs text-muted-foreground flex items-center mt-1">
                        <Clock className="w-3 h-3 mr-1" />
                        {review.timestamp}
                      </p>
                    </div>
                    <Badge variant="outline" className="bg-primary/10 text-primary border-primary/20">
                      <span className={getFraudScoreColor(review.fraudScore)}>
                        Fraud Score: {review.fraudScore}%
                      </span>
                    </Badge>
                  </div>

                  <div className="flex items-center gap-4 p-3 bg-muted/50 rounded-lg">
                    <div className="flex items-center space-x-2">
                      <CheckCircle className="w-4 h-4 text-success" />
                      <span className="text-sm font-medium">{review.votes.approve} Approve</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <XCircle className="w-4 h-4 text-destructive" />
                      <span className="text-sm font-medium">{review.votes.reject} Reject</span>
                    </div>
                  </div>

                  <div className="flex gap-3">
                    <Button className="flex-1 bg-success text-white hover:bg-success/90">
                      <CheckCircle className="w-4 h-4 mr-2" />
                      Approve
                    </Button>
                    <Button variant="destructive" className="flex-1">
                      <XCircle className="w-4 h-4 mr-2" />
                      Reject
                    </Button>
                  </div>
                </div>
              </Card>
            ))}
          </div>

          {/* Team Members */}
          <div className="space-y-6">
            <h2 className="text-2xl font-bold">Team Members</h2>
            <Card className="p-6">
              <div className="space-y-4">
                {teamMembers.map((member, index) => (
                  <div key={index} className="flex items-center space-x-3 p-3 rounded-lg hover:bg-muted/50 transition-colors">
                    <div className="relative">
                      <Avatar>
                        <AvatarFallback className="bg-primary/10 text-primary font-semibold">
                          {member.initials}
                        </AvatarFallback>
                      </Avatar>
                      <div
                        className={`absolute bottom-0 right-0 w-3 h-3 rounded-full border-2 border-background ${getStatusColor(
                          member.status
                        )}`}
                      />
                    </div>
                    <div className="flex-1">
                      <p className="font-semibold text-sm">{member.name}</p>
                      <p className="text-xs text-muted-foreground">{member.role}</p>
                    </div>
                    <Badge variant="outline" className="text-xs capitalize">
                      {member.status}
                    </Badge>
                  </div>
                ))}
              </div>
            </Card>
          </div>
        </div>
      </main>
    </div>
  );
}
