import { useState, useRef } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Shield, Upload, CheckCircle, Calendar, Globe, Camera, Scan } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { useToast } from "@/hooks/use-toast";
import ScanHeader from "@/components/scan/ScanHeader";
import VerificationResults from "@/components/scan/VerificationResults";
import { supabase } from "@/integrations/supabase/client";
import { convertImageToBase64 } from "@/utils/imageUtils";

export default function VisaScan() {
  const navigate = useNavigate();
  const { toast } = useToast();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [scanning, setScanning] = useState(false);
  const [scanned, setScanned] = useState(false);
  const [results, setResults] = useState<any>(null);

  const handleUploadClick = () => {
    fileInputRef.current?.click();
  };

  const handleScan = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    setScanning(true);
    
    try {
      // Get current user
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) {
        toast({
          title: "Authentication Required",
          description: "Please log in to scan documents.",
          variant: "destructive",
        });
        navigate("/");
        return;
      }

      const imageData = await convertImageToBase64(file);
      
      const { data, error } = await supabase.functions.invoke('analyze-document', {
        body: { imageData, documentType: 'visa' }
      });

      if (error) throw error;

      const processedResults = {
        fraudScore: data.fraudScore || 0,
        data: {
          visaType: data.visaType || "N/A",
          visaNumber: data.visaNumber || "N/A",
          country: data.country || "N/A",
          entryValidity: data.validFrom || "N/A",
          exitValidity: data.validUntil || "N/A",
        },
        security: {},
        warnings: data.warnings || [],
      };

      if (data.securityFeatures) {
        data.securityFeatures.forEach((feature: any) => {
          processedResults.security[feature.name] = {
            status: feature.status,
            confidence: feature.confidence
          };
        });
      }

      // Save scan to database
      const scanStatus = processedResults.fraudScore >= 80 ? 'completed' : 
                        processedResults.fraudScore >= 60 ? 'completed' : 'failed';
      
      const { error: insertError } = await supabase
        .from('scans')
        .insert({
          user_id: user.id,
          document_type: 'visa',
          status: scanStatus,
          result: processedResults
        });

      if (insertError) {
        console.error('Error saving scan:', insertError);
      }

      setResults(processedResults);
      setScanned(true);
      
      toast({
        title: "Visa Scan Complete",
        description: `Verification score: ${processedResults.fraudScore}/100`,
      });
    } catch (error) {
      console.error('Scan error:', error);
      toast({
        title: "Scan Failed",
        description: "Failed to analyze visa. Please try again.",
        variant: "destructive",
      });
    } finally {
      setScanning(false);
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <ScanHeader title="Visa Verification" onBack={() => navigate("/dashboard")} />

      <main className="container mx-auto px-4 py-8 max-w-6xl">
        {!scanned ? (
          <div className="space-y-8 animate-slide-up">
            <Card className="relative overflow-hidden border-border/50 shadow-large">
              <div className="relative p-12 text-center">
                <div className="w-24 h-24 bg-primary rounded-3xl flex items-center justify-center mx-auto mb-6 shadow-medium">
                  <Shield className="w-12 h-12 text-primary-foreground" />
                </div>
                <h2 className="text-3xl font-bold mb-3 text-foreground">
                  Intelligent Visa Authentication
                </h2>
                <p className="text-muted-foreground text-lg mb-8 max-w-2xl mx-auto">
                  Real-time visa validation with embassy verification, stamp analysis, and expiry date monitoring
                </p>

                <input 
                  ref={fileInputRef}
                  type="file" 
                  accept="image/*" 
                  className="hidden" 
                  onChange={handleScan} 
                  disabled={scanning} 
                />
                
                <div className="flex flex-col sm:flex-row gap-4 justify-center mb-8">
                  <Button 
                    size="lg" 
                    className="w-full sm:w-auto text-base px-8" 
                    disabled={scanning}
                    onClick={handleUploadClick}
                  >
                    <Upload className="mr-2 w-5 h-5" />
                    {scanning ? "Analyzing..." : "Upload Visa Document"}
                  </Button>
                  <Button 
                    size="lg" 
                    variant="outline"
                    className="w-full sm:w-auto text-base px-8" 
                    disabled
                  >
                    <Camera className="mr-2 w-5 h-5" />
                    Connect Camera
                  </Button>
                  <Button 
                    size="lg" 
                    variant="outline"
                    className="w-full sm:w-auto text-base px-8" 
                    disabled
                  >
                    <Scan className="mr-2 w-5 h-5" />
                    Connect Scanner
                  </Button>
                </div>

                <div className="grid grid-cols-3 gap-6 max-w-3xl mx-auto">
                  <div className="flex flex-col items-center p-4 rounded-xl bg-card/50 backdrop-blur-sm border border-border/50">
                    <CheckCircle className="w-8 h-8 text-success mb-2" />
                    <p className="text-sm font-medium">Stamp Verification</p>
                  </div>
                  <div className="flex flex-col items-center p-4 rounded-xl bg-card/50 backdrop-blur-sm border border-border/50">
                    <Calendar className="w-8 h-8 text-warning mb-2" />
                    <p className="text-sm font-medium">Date Validation</p>
                  </div>
                  <div className="flex flex-col items-center p-4 rounded-xl bg-card/50 backdrop-blur-sm border border-border/50">
                    <Globe className="w-8 h-8 text-info mb-2" />
                    <p className="text-sm font-medium">Embassy Check</p>
                  </div>
                </div>
              </div>
            </Card>

            {scanning && (
              <Card className="p-12 shadow-large border-border/50 relative overflow-hidden bg-card/50 backdrop-blur-sm">
                <div className="relative text-center">
                  <div className="w-20 h-20 mx-auto mb-6 relative">
                    <div className="absolute inset-0 border-4 border-primary/30 rounded-full"></div>
                    <div className="absolute inset-0 border-4 border-primary border-t-transparent rounded-full animate-spin"></div>
                  </div>
                  <h3 className="text-2xl font-bold mb-3">Authenticating Visa Document</h3>
                  <p className="text-muted-foreground text-lg">
                    Verifying stamps, dates, and embassy authorization
                  </p>
                </div>
              </Card>
            )}
          </div>
        ) : (
          <VerificationResults results={results} type="visa" onNewScan={() => setScanned(false)} />
        )}
      </main>
    </div>
  );
}
