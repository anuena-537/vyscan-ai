import { Card } from "@/components/ui/card";
import { Upload, Camera, Scan, CheckCircle } from "lucide-react";

export default function ScanMethodsGuide() {
  return (
    <div className="space-y-6 animate-slide-up">
      <div className="text-center mb-8">
        <h2 className="text-3xl font-bold mb-3">Ways to Scan Documents</h2>
        <p className="text-muted-foreground text-lg">
          Choose the scanning method that works best for your workflow
        </p>
      </div>

      <div className="grid md:grid-cols-3 gap-6">
        <Card className="p-6 border-border/50 hover:border-primary/50 transition-all">
          <div className="w-16 h-16 bg-primary/10 rounded-2xl flex items-center justify-center mb-4">
            <Upload className="w-8 h-8 text-primary" />
          </div>
          <h3 className="text-xl font-semibold mb-3">Manual Upload</h3>
          <p className="text-muted-foreground mb-4">
            Upload pre-captured document images from your device
          </p>
          <div className="space-y-2">
            <div className="flex items-start space-x-2">
              <CheckCircle className="w-4 h-4 text-primary mt-0.5 flex-shrink-0" />
              <p className="text-sm text-muted-foreground">
                Select files from your computer or mobile device
              </p>
            </div>
            <div className="flex items-start space-x-2">
              <CheckCircle className="w-4 h-4 text-primary mt-0.5 flex-shrink-0" />
              <p className="text-sm text-muted-foreground">
                Supports JPEG, PNG, and PDF formats
              </p>
            </div>
            <div className="flex items-start space-x-2">
              <CheckCircle className="w-4 h-4 text-primary mt-0.5 flex-shrink-0" />
              <p className="text-sm text-muted-foreground">
                Process multiple documents in batch
              </p>
            </div>
            <div className="flex items-start space-x-2">
              <CheckCircle className="w-4 h-4 text-primary mt-0.5 flex-shrink-0" />
              <p className="text-sm text-muted-foreground">
                Best for pre-scanned documents
              </p>
            </div>
          </div>
        </Card>

        <Card className="p-6 border-border/50 hover:border-primary/50 transition-all">
          <div className="w-16 h-16 bg-accent/10 rounded-2xl flex items-center justify-center mb-4">
            <Camera className="w-8 h-8 text-accent" />
          </div>
          <h3 className="text-xl font-semibold mb-3">Real-Time Camera</h3>
          <p className="text-muted-foreground mb-4">
            Capture documents instantly using your device camera
          </p>
          <div className="space-y-2">
            <div className="flex items-start space-x-2">
              <CheckCircle className="w-4 h-4 text-primary mt-0.5 flex-shrink-0" />
              <p className="text-sm text-muted-foreground">
                Live camera feed with instant capture
              </p>
            </div>
            <div className="flex items-start space-x-2">
              <CheckCircle className="w-4 h-4 text-primary mt-0.5 flex-shrink-0" />
              <p className="text-sm text-muted-foreground">
                Automatic edge detection and alignment
              </p>
            </div>
            <div className="flex items-start space-x-2">
              <CheckCircle className="w-4 h-4 text-primary mt-0.5 flex-shrink-0" />
              <p className="text-sm text-muted-foreground">
                Quality checks before submission
              </p>
            </div>
            <div className="flex items-start space-x-2">
              <CheckCircle className="w-4 h-4 text-primary mt-0.5 flex-shrink-0" />
              <p className="text-sm text-muted-foreground">
                Perfect for on-the-go scanning
              </p>
            </div>
          </div>
        </Card>

        <Card className="p-6 border-border/50 hover:border-primary/50 transition-all">
          <div className="w-16 h-16 bg-info/10 rounded-2xl flex items-center justify-center mb-4">
            <Scan className="w-8 h-8 text-info" />
          </div>
          <h3 className="text-xl font-semibold mb-3">Scanner Integration</h3>
          <p className="text-muted-foreground mb-4">
            Connect directly to professional document scanners
          </p>
          <div className="space-y-2">
            <div className="flex items-start space-x-2">
              <CheckCircle className="w-4 h-4 text-primary mt-0.5 flex-shrink-0" />
              <p className="text-sm text-muted-foreground">
                Direct connection to USB/network scanners
              </p>
            </div>
            <div className="flex items-start space-x-2">
              <CheckCircle className="w-4 h-4 text-primary mt-0.5 flex-shrink-0" />
              <p className="text-sm text-muted-foreground">
                High-resolution scanning (600+ DPI)
              </p>
            </div>
            <div className="flex items-start space-x-2">
              <CheckCircle className="w-4 h-4 text-primary mt-0.5 flex-shrink-0" />
              <p className="text-sm text-muted-foreground">
                Automatic document feeder support
              </p>
            </div>
            <div className="flex items-start space-x-2">
              <CheckCircle className="w-4 h-4 text-primary mt-0.5 flex-shrink-0" />
              <p className="text-sm text-muted-foreground">
                Enterprise-grade for high-volume processing
              </p>
            </div>
          </div>
        </Card>
      </div>
    </div>
  );
}
