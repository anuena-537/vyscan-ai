import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { CheckCircle, AlertTriangle, XCircle, RotateCcw, Shield, FileText, Download } from "lucide-react";
import { exportVerificationToPDF } from "@/utils/pdfExport";

interface BusinessDocResultsProps {
  results: any;
  onNewScan: () => void;
}

export default function BusinessDocResults({ results, onNewScan }: BusinessDocResultsProps) {
  const getScoreColor = (score: number) => {
    if (score >= 90) return "text-success";
    if (score >= 70) return "text-warning";
    return "text-destructive";
  };

  const getScoreBg = (score: number) => {
    if (score >= 90) return "bg-success/10";
    if (score >= 70) return "bg-warning/10";
    return "bg-destructive/10";
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "verified":
        return <CheckCircle className="w-5 h-5 text-success" />;
      case "warning":
        return <AlertTriangle className="w-5 h-5 text-warning" />;
      case "failed":
        return <XCircle className="w-5 h-5 text-destructive" />;
      default:
        return null;
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case "verified":
        return "Verified";
      case "warning":
        return "Review Needed";
      case "failed":
        return "Failed";
      default:
        return "Unknown";
    }
  };

  return (
    <div className="space-y-6 animate-slide-up">
      {/* Tamper Detection Score */}
      <Card className="p-8 shadow-soft border-border/50 bg-card text-center">
        <div className="flex items-center justify-center space-x-2 mb-4">
          <Shield className="w-6 h-6 text-primary" />
          <h2 className="text-xl font-semibold">Tamper Detection Analysis</h2>
        </div>
        
        <div className={`inline-flex items-center justify-center w-32 h-32 rounded-full ${getScoreBg(results.tamperScore)} mb-4`}>
          <div className="text-center">
            <div className={`text-4xl font-bold ${getScoreColor(results.tamperScore)}`}>
              {results.tamperScore}
            </div>
            <div className="text-sm text-muted-foreground">Score</div>
          </div>
        </div>
        
        <div className="mb-4">
          <Badge variant="secondary" className="text-sm px-4 py-1 mb-2">
            {results.documentType}
          </Badge>
        </div>

        <p className="text-muted-foreground mb-4">
          {results.tamperScore >= 90 ? "Document appears authentic and untampered" : 
           results.tamperScore >= 70 ? "Document shows minor inconsistencies - manual review recommended" : 
           "High tampering risk detected - verification required"}
        </p>

        {results.warnings.length > 0 && (
          <div className="bg-warning/10 border border-warning/20 rounded-lg p-4 mb-4">
            <div className="flex items-start space-x-2 text-left">
              <AlertTriangle className="w-5 h-5 text-warning mt-0.5 flex-shrink-0" />
              <div className="space-y-2">
                <p className="text-sm font-semibold text-warning">Warnings Detected:</p>
                {results.warnings.map((warning: string, index: number) => (
                  <p key={index} className="text-sm text-warning">
                    • {warning}
                  </p>
                ))}
              </div>
            </div>
          </div>
        )}

        <Button onClick={onNewScan} variant="outline">
          <RotateCcw className="mr-2 w-4 h-4" />
          Scan Another Document
        </Button>
        <Button 
          variant="ghost"
          onClick={() => exportVerificationToPDF(results, results.documentType || 'business')}
        >
          <Download className="mr-2 w-4 h-4" />
          Export PDF Report
        </Button>
      </Card>

      {/* Extracted Data */}
      <Card className="p-6 shadow-soft border-border/50 bg-card">
        <div className="flex items-center space-x-2 mb-4">
          <FileText className="w-5 h-5 text-primary" />
          <h3 className="text-lg font-semibold">Extracted Information</h3>
        </div>
        <div className="grid md:grid-cols-2 gap-4">
          {Object.entries(results.data).map(([key, value]) => (
            <div key={key} className="flex flex-col p-3 bg-muted/30 rounded-lg">
              <span className="text-xs font-medium text-muted-foreground capitalize mb-1">
                {key.replace(/([A-Z])/g, ' $1').trim()}
              </span>
              <span className="text-sm font-semibold">{value as string}</span>
            </div>
          ))}
        </div>
      </Card>

      {/* Tamper Detection Checks */}
      <Card className="p-6 shadow-soft border-border/50 bg-card">
        <div className="flex items-center space-x-2 mb-4">
          <Shield className="w-5 h-5 text-primary" />
          <h3 className="text-lg font-semibold">Tamper Detection Results</h3>
        </div>
        <div className="grid md:grid-cols-2 gap-4">
          {Object.entries(results.tamperChecks).map(([key, check]: [string, any]) => (
            <div key={key} className="p-4 bg-muted/30 rounded-lg">
              <div className="flex items-start justify-between mb-2">
                <div className="flex items-center space-x-2 flex-1">
                  {getStatusIcon(check.status)}
                  <span className="text-sm font-medium capitalize">
                    {key.replace(/([A-Z])/g, ' $1').trim()}
                  </span>
                </div>
                <Badge 
                  variant="secondary" 
                  className={`text-xs ml-2 ${
                    check.status === "verified" ? "bg-success/10 text-success" :
                    check.status === "warning" ? "bg-warning/10 text-warning" :
                    "bg-destructive/10 text-destructive"
                  }`}
                >
                  {check.confidence}%
                </Badge>
              </div>
              <p className="text-xs text-muted-foreground ml-7">
                {getStatusText(check.status)}
              </p>
            </div>
          ))}
        </div>
      </Card>

      {/* Tampering Indicators Legend */}
      <Card className="p-6 shadow-soft border-border/50 bg-card">
        <h3 className="text-lg font-semibold mb-4">Detection Methods</h3>
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4 text-sm">
          <div className="flex items-start space-x-2">
            <div className="w-2 h-2 bg-primary rounded-full mt-1.5"></div>
            <div>
              <p className="font-medium">Font Consistency</p>
              <p className="text-muted-foreground text-xs">Detects font style changes and digital alterations</p>
            </div>
          </div>
          <div className="flex items-start space-x-2">
            <div className="w-2 h-2 bg-primary rounded-full mt-1.5"></div>
            <div>
              <p className="font-medium">Paper Texture Analysis</p>
              <p className="text-muted-foreground text-xs">Validates authentic paper quality and texture</p>
            </div>
          </div>
          <div className="flex items-start space-x-2">
            <div className="w-2 h-2 bg-primary rounded-full mt-1.5"></div>
            <div>
              <p className="font-medium">Digital Forensics</p>
              <p className="text-muted-foreground text-xs">Analyzes metadata and creation history</p>
            </div>
          </div>
          <div className="flex items-start space-x-2">
            <div className="w-2 h-2 bg-primary rounded-full mt-1.5"></div>
            <div>
              <p className="font-medium">Signature Verification</p>
              <p className="text-muted-foreground text-xs">Authenticates handwritten and digital signatures</p>
            </div>
          </div>
          <div className="flex items-start space-x-2">
            <div className="w-2 h-2 bg-primary rounded-full mt-1.5"></div>
            <div>
              <p className="font-medium">Logo Authentication</p>
              <p className="text-muted-foreground text-xs">Verifies company logos and official stamps</p>
            </div>
          </div>
          <div className="flex items-start space-x-2">
            <div className="w-2 h-2 bg-primary rounded-full mt-1.5"></div>
            <div>
              <p className="font-medium">Date Consistency</p>
              <p className="text-muted-foreground text-xs">Cross-checks dates and timestamps</p>
            </div>
          </div>
        </div>
      </Card>
    </div>
  );
}
