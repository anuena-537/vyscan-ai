import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { CheckCircle, AlertTriangle, XCircle, RotateCcw, Download } from "lucide-react";
import { exportVerificationToPDF } from "@/utils/pdfExport";

interface VerificationResultsProps {
  results: any;
  type: "passport" | "visa" | "document";
  onNewScan: () => void;
}

export default function VerificationResults({ results, type, onNewScan }: VerificationResultsProps) {
  const getScoreColor = (score: number) => {
    if (score >= 90) return "text-success";
    if (score >= 70) return "text-warning";
    return "text-destructive";
  };

  const getScoreBg = (score: number) => {
    if (score >= 90) return "bg-success/10";
    if (score >= 70) return "bg-warning/10";
    return "bg-destructive/10";
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "verified":
        return <CheckCircle className="w-5 h-5 text-success" />;
      case "warning":
        return <AlertTriangle className="w-5 h-5 text-warning" />;
      case "failed":
        return <XCircle className="w-5 h-5 text-destructive" />;
      default:
        return null;
    }
  };

  return (
    <div className="space-y-6 animate-slide-up">
      {/* Fraud Score */}
      <Card className="p-8 shadow-soft border-border/50 bg-card text-center">
        <h2 className="text-xl font-semibold mb-4">Verification Complete</h2>
        <div className={`inline-flex items-center justify-center w-32 h-32 rounded-full ${getScoreBg(results.fraudScore)} mb-4`}>
          <div className="text-center">
            <div className={`text-4xl font-bold ${getScoreColor(results.fraudScore)}`}>
              {results.fraudScore}
            </div>
            <div className="text-sm text-muted-foreground">Score</div>
          </div>
        </div>
        <p className="text-muted-foreground mb-4">
          {results.fraudScore >= 90 ? "Document appears authentic" : 
           results.fraudScore >= 70 ? "Document requires manual review" : 
           "High fraud risk detected"}
        </p>
        {results.warnings.length > 0 && (
          <div className="bg-warning/10 border border-warning/20 rounded-lg p-4 mb-4">
            {results.warnings.map((warning: string, index: number) => (
              <p key={index} className="text-sm text-warning flex items-center justify-center">
                <AlertTriangle className="w-4 h-4 mr-2" />
                {warning}
              </p>
            ))}
          </div>
        )}
        <Button onClick={onNewScan} variant="outline">
          <RotateCcw className="mr-2 w-4 h-4" />
          Scan Another Document
        </Button>
        <Button 
          variant="ghost"
          onClick={() => exportVerificationToPDF(results, type)}
        >
          <Download className="mr-2 w-4 h-4" />
          Export PDF Report
        </Button>
      </Card>

      {/* Extracted Data */}
      <Card className="p-6 shadow-soft border-border/50 bg-card">
        <h3 className="text-lg font-semibold mb-4">Extracted Information</h3>
        <div className="grid md:grid-cols-2 gap-4">
          {Object.entries(results.data).map(([key, value]) => (
            <div key={key} className="flex justify-between p-3 bg-muted/30 rounded-lg">
              <span className="text-sm font-medium capitalize">
                {key.replace(/([A-Z])/g, ' $1').trim()}
              </span>
              <span className="text-sm text-muted-foreground">{value as string}</span>
            </div>
          ))}
        </div>
      </Card>

      {/* Security Features */}
      <Card className="p-6 shadow-soft border-border/50 bg-card">
        <h3 className="text-lg font-semibold mb-4">Security Features Verification</h3>
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
          {Object.entries(results.security).map(([key, feature]: [string, any]) => (
            <div key={key} className="flex items-center justify-between p-4 bg-muted/30 rounded-lg">
              <div className="flex items-center space-x-3">
                {getStatusIcon(feature.status)}
                <span className="text-sm font-medium capitalize">
                  {key.replace(/([A-Z])/g, ' $1').trim()}
                </span>
              </div>
              <Badge variant="secondary" className="text-xs">
                {feature.confidence}%
              </Badge>
            </div>
          ))}
        </div>
      </Card>
    </div>
  );
}
