import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { CheckCircle, AlertTriangle, XCircle, Clock } from "lucide-react";
import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";

interface Activity {
  id: string;
  type: string;
  title: string;
  description: string;
  time: string;
  score: number;
}

export default function RecentActivity() {
  const [activities, setActivities] = useState<Activity[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchRecentScans();
  }, []);

  const fetchRecentScans = async () => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      const { data: scans, error } = await supabase
        .from('scans')
        .select('*')
        .eq('user_id', user.id)
        .order('created_at', { ascending: false })
        .limit(5);

      if (error) throw error;

      const mappedActivities: Activity[] = scans?.map(scan => {
        const result = scan.result as any;
        const score = result?.fraudScore || result?.tamperScore || result?.verificationScore || 0;
        const warnings = result?.warnings || [];
        
        let type = 'success';
        let title = 'Document Verified';
        
        if (score >= 70) {
          type = 'error';
          title = 'Fraud Suspected';
        } else if (score >= 40) {
          type = 'warning';
          title = 'Review Required';
        }

        const docTypeMap: Record<string, string> = {
          passport: 'Passport',
          visa: 'Visa',
          boarding_pass: 'Boarding Pass',
          business_authorization: 'Business Authorization',
          business_invitation: 'Business Invitation',
          biometric: 'Biometric Verification'
        };

        const docName = result?.fullName || result?.documentNumber || 'Document';
        const description = `${docTypeMap[scan.document_type] || scan.document_type} - ${docName}`;
        
        const timeDiff = Date.now() - new Date(scan.created_at).getTime();
        const minutes = Math.floor(timeDiff / 60000);
        const hours = Math.floor(minutes / 60);
        const days = Math.floor(hours / 24);
        
        let time;
        if (days > 0) time = `${days} day${days > 1 ? 's' : ''} ago`;
        else if (hours > 0) time = `${hours} hour${hours > 1 ? 's' : ''} ago`;
        else if (minutes > 0) time = `${minutes} minute${minutes > 1 ? 's' : ''} ago`;
        else time = 'Just now';

        return {
          id: scan.id,
          type,
          title,
          description,
          time,
          score
        };
      }) || [];

      setActivities(mappedActivities);
    } catch (error) {
      console.error('Error fetching recent scans:', error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <Card className="p-6 shadow-soft border-border/50 bg-card">
        <h3 className="text-xl font-bold mb-4">Recent Activity</h3>
        <div className="space-y-4">
          {[1, 2, 3].map((i) => (
            <div key={i} className="animate-pulse">
              <div className="h-20 bg-muted rounded-xl"></div>
            </div>
          ))}
        </div>
      </Card>
    );
  }

  if (activities.length === 0) {
    return (
      <Card className="p-6 shadow-soft border-border/50 bg-card">
        <h3 className="text-xl font-bold mb-4">Recent Activity</h3>
        <div className="text-center py-8 text-muted-foreground">
          <Clock className="w-12 h-12 mx-auto mb-2 opacity-50" />
          <p>No recent activity</p>
          <p className="text-sm">Start scanning documents to see activity here</p>
        </div>
      </Card>
    );
  }

  const oldActivities = [
    {
      id: 1,
      type: "success",
      title: "Passport Verified",
      description: "USA Passport - John Smith #P123456789",
      time: "2 minutes ago",
      score: 98,
    },
    {
      id: 2,
      type: "warning",
      title: "Visa Expiry Warning",
      description: "UK Visa - Sarah Johnson - Expires in 7 days",
      time: "15 minutes ago",
      score: 85,
    },
    {
      id: 3,
      type: "error",
      title: "Fraud Detected",
      description: "Passport MRZ tampering detected - #F987654321",
      time: "1 hour ago",
      score: 23,
    },
    {
      id: 4,
      type: "success",
      title: "Biometric Match",
      description: "Face verification passed - Match confidence: 97.8%",
      time: "2 hours ago",
      score: 97,
    },
    {
      id: 5,
      type: "warning",
      title: "Document Review Needed",
      description: "Business authorization letter requires manual review",
      time: "3 hours ago",
      score: 72,
    },
  ];

  const getIcon = (type: string) => {
    switch (type) {
      case "success":
        return <CheckCircle className="w-5 h-5 text-success" />;
      case "warning":
        return <AlertTriangle className="w-5 h-5 text-warning" />;
      case "error":
        return <XCircle className="w-5 h-5 text-destructive" />;
      default:
        return <Clock className="w-5 h-5 text-muted-foreground" />;
    }
  };

  const getScoreColor = (score: number) => {
    if (score >= 90) return "bg-success/10 text-success";
    if (score >= 70) return "bg-warning/10 text-warning";
    return "bg-destructive/10 text-destructive";
  };

  return (
    <Card className="p-6 shadow-soft border-border/50 bg-card">
      <h3 className="text-xl font-bold mb-4">Recent Activity</h3>
      <div className="space-y-4">
        {activities.map((activity) => (
          <div
            key={activity.id}
            className="flex items-start space-x-4 p-4 rounded-xl border border-border hover:border-primary/50 transition-all duration-300 bg-card"
          >
            <div className="mt-1">{getIcon(activity.type)}</div>
            <div className="flex-1 min-w-0">
              <div className="flex items-start justify-between mb-1">
                <h4 className="font-semibold text-sm">{activity.title}</h4>
                <Badge className={getScoreColor(activity.score)} variant="secondary">
                  Score: {activity.score}
                </Badge>
              </div>
              <p className="text-sm text-muted-foreground mb-1">{activity.description}</p>
              <p className="text-xs text-muted-foreground">{activity.time}</p>
            </div>
          </div>
        ))}
      </div>
    </Card>
  );
}
