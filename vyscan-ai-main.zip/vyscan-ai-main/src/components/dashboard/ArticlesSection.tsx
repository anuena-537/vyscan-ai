import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { BookOpen, ArrowRight, Calendar, Clock } from "lucide-react";

export default function ArticlesSection() {
  const articles = [
    {
      id: 1,
      title: "New AI Model Deployment: Enhanced Fraud Detection",
      excerpt: "We've upgraded our AI systems with advanced machine learning models that improve fraud detection accuracy by 23%.",
      category: "Product Update",
      date: "2025-01-15",
      readTime: "4 min read",
      image: "🤖",
    },
    {
      id: 2,
      title: "Biometric Verification: Best Practices for 2025",
      excerpt: "Learn about the latest trends in biometric authentication and how to implement them effectively in your workflow.",
      category: "Security Guide",
      date: "2025-01-12",
      readTime: "6 min read",
      image: "🔐",
    },
    {
      id: 3,
      title: "Mobile Document Scanning: Tips for Better Results",
      excerpt: "Discover how to capture high-quality document images using your smartphone for optimal verification results.",
      category: "Tips & Tricks",
      date: "2025-01-10",
      readTime: "3 min read",
      image: "📱",
    },
    {
      id: 4,
      title: "VisionPass Q4 2024: Year in Review",
      excerpt: "2024 was an incredible year! We processed over 10 million documents and prevented $50M in fraud. Here's our journey.",
      category: "Company News",
      date: "2025-01-05",
      readTime: "5 min read",
      image: "🎉",
    },
  ];

  return (
    <Card className="p-6 shadow-soft border-border/50 bg-card">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center space-x-2">
          <BookOpen className="w-5 h-5 text-primary" />
          <h3 className="text-xl font-bold">Latest from VisionPass</h3>
        </div>
        <Button variant="ghost" size="sm">
          View All
          <ArrowRight className="w-4 h-4 ml-2" />
        </Button>
      </div>

      <div className="grid md:grid-cols-2 gap-4">
        {articles.map((article) => (
          <Card
            key={article.id}
            className="p-4 hover:border-primary/50 transition-all duration-300 cursor-pointer group"
          >
            <div className="flex items-start space-x-4">
              <div className="text-4xl">{article.image}</div>
              <div className="flex-1 min-w-0">
                <Badge variant="secondary" className="mb-2 text-xs">
                  {article.category}
                </Badge>
                <h4 className="font-semibold text-sm mb-2 line-clamp-2 group-hover:text-primary transition-colors">
                  {article.title}
                </h4>
                <p className="text-xs text-muted-foreground mb-3 line-clamp-2">
                  {article.excerpt}
                </p>
                <div className="flex items-center space-x-3 text-xs text-muted-foreground">
                  <div className="flex items-center space-x-1">
                    <Calendar className="w-3 h-3" />
                    <span>{new Date(article.date).toLocaleDateString()}</span>
                  </div>
                  <div className="flex items-center space-x-1">
                    <Clock className="w-3 h-3" />
                    <span>{article.readTime}</span>
                  </div>
                </div>
              </div>
            </div>
          </Card>
        ))}
      </div>
    </Card>
  );
}
