import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { FileText, Camera, Shield, Search, Briefcase, History, ArrowRight } from "lucide-react";
import { useNavigate } from "react-router-dom";

export default function QuickActions() {
  const navigate = useNavigate();

  const actions = [
    {
      icon: FileText,
      title: "Scan Passport",
      description: "Verify passport authenticity and extract data",
      color: "bg-primary/10 text-primary",
      onClick: () => navigate("/scan/passport"),
    },
    {
      icon: Shield,
      title: "Verify Visa",
      description: "Check visa validity and authorization",
      color: "bg-primary/10 text-primary",
      onClick: () => navigate("/scan/visa"),
    },
    {
      icon: Briefcase,
      title: "Business Docs",
      description: "Verify boarding passes and authorization letters",
      color: "bg-primary/10 text-primary",
      onClick: () => navigate("/scan/business"),
    },
    {
      icon: Camera,
      title: "Biometric Check",
      description: "Perform facial recognition verification",
      color: "bg-info/10 text-info",
      onClick: () => navigate("/biometric"),
    },
    {
      icon: Search,
      title: "Watchlist Search",
      description: "Check against security databases",
      color: "bg-warning/10 text-warning",
      onClick: () => navigate("/watchlist"),
    },
    {
      icon: History,
      title: "Scan History",
      description: "View past verification records",
      color: "bg-success/10 text-success",
      onClick: () => navigate("/history"),
    },
  ];

  return (
    <Card className="p-6 shadow-soft border-border/50">
      <h3 className="text-xl font-bold mb-4">Quick Actions</h3>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-4">
        {actions.map((action, index) => (
          <button
            key={index}
            onClick={action.onClick}
            className="group relative text-left p-4 rounded-xl border border-border hover:border-primary/50 transition-all duration-300 hover:shadow-soft bg-card"
          >
            <div className={`w-10 h-10 rounded-lg flex items-center justify-center mb-3 ${action.color}`}>
              <action.icon className="w-5 h-5" />
            </div>
            <h4 className="font-semibold mb-1">{action.title}</h4>
            <p className="text-xs text-muted-foreground">{action.description}</p>
            <ArrowRight className="absolute top-4 right-4 w-4 h-4 text-primary opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
          </button>
        ))}
      </div>
    </Card>
  );
}
