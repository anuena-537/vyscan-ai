import { Card } from "@/components/ui/card";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from "recharts";

interface ScanStats {
  total: number;
  completed: number;
  failed: number;
  processing: number;
  byType: Record<string, number>;
}

interface AnalyticsChartProps {
  stats: ScanStats;
}

export default function AnalyticsChart({ stats }: AnalyticsChartProps) {
  const statusData = [
    { name: 'Completed', value: stats.completed, color: 'hsl(142 71% 45%)' },
    { name: 'Failed', value: stats.failed, color: 'hsl(0 84% 60%)' },
    { name: 'Processing', value: stats.processing, color: 'hsl(38 92% 50%)' }
  ].filter(item => item.value > 0);

  const typeData = Object.entries(stats.byType).map(([type, count]) => ({
    name: type.replace('_', ' ').replace(/\b\w/g, l => l.toUpperCase()),
    value: count
  }));

  return (
    <Card className="p-6 shadow-medium">
      <h3 className="text-lg font-semibold mb-4">Scan Analytics</h3>
      {stats.total === 0 ? (
        <div className="flex items-center justify-center h-64 text-muted-foreground">
          <div className="text-center">
            <p className="text-lg font-medium">No scan data yet</p>
            <p className="text-sm">Start scanning to see analytics</p>
          </div>
        </div>
      ) : (
        <div className="space-y-8">
          {statusData.length > 0 && (
            <ResponsiveContainer width="100%" height={200}>
              <PieChart>
                <Pie data={statusData} cx="50%" cy="50%" outerRadius={80} dataKey="value" label>
                  {statusData.map((entry, index) => <Cell key={`cell-${index}`} fill={entry.color} />)}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          )}
          {typeData.length > 0 && (
            <ResponsiveContainer width="100%" height={200}>
              <BarChart data={typeData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="name" />
                <YAxis />
                <Tooltip />
                <Bar dataKey="value" fill="hsl(203 100% 56%)" radius={[8, 8, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          )}
        </div>
      )}
    </Card>
  );
}
