import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { AlertTriangle, Eye } from "lucide-react";
import { useNavigate } from "react-router-dom";

interface FlaggedDocument {
  id: string;
  document_type: string;
  created_at: string;
  result: any;
}

interface FlaggedDocumentsProps {
  flaggedDocs: FlaggedDocument[];
}

export default function FlaggedDocuments({ flaggedDocs }: FlaggedDocumentsProps) {
  const navigate = useNavigate();

  const getFraudScore = (result: any) => {
    return result?.fraudScore || result?.tamperScore || 0;
  };

  const getDocumentTypeName = (type: string) => {
    const types: Record<string, string> = {
      passport: "Passport",
      visa: "Visa",
      boarding: "Boarding Pass",
      authorization: "Authorization Letter",
      invitation: "Invitation Letter",
      biometric: "Biometric Verification"
    };
    return types[type] || type;
  };

  if (flaggedDocs.length === 0) {
    return null;
  }

  return (
    <Card className="p-6 border-destructive/20">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center space-x-2">
          <AlertTriangle className="w-5 h-5 text-destructive" />
          <h3 className="text-lg font-semibold">Suspected Documents</h3>
          <Badge variant="destructive">{flaggedDocs.length}</Badge>
        </div>
        <Button variant="outline" size="sm" onClick={() => navigate("/scan-history")}>
          View All
        </Button>
      </div>
      
      <div className="space-y-3">
        {flaggedDocs.slice(0, 5).map((doc) => {
          const fraudScore = getFraudScore(doc.result);
          const warnings = doc.result?.warnings || [];
          const isSuspected = warnings.some((w: string) => w.includes("SUSPECTED FAKE"));

          return (
            <div
              key={doc.id}
              className="flex items-center justify-between p-4 bg-destructive/5 rounded-lg border border-destructive/20 hover:border-destructive/40 transition-colors"
            >
              <div className="flex-1">
                <div className="flex items-center space-x-2 mb-1">
                  <span className="font-medium">{getDocumentTypeName(doc.document_type)}</span>
                  <Badge variant="destructive" className="text-xs">
                    Risk Score: {fraudScore}%
                  </Badge>
                  {isSuspected && (
                    <Badge variant="destructive" className="text-xs">
                      Manual Review Required
                    </Badge>
                  )}
                </div>
                <p className="text-xs text-muted-foreground">
                  {new Date(doc.created_at).toLocaleString()}
                </p>
                {warnings.length > 0 && (
                  <p className="text-xs text-destructive mt-1 line-clamp-1">
                    {warnings[0]}
                  </p>
                )}
              </div>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => navigate("/scan-history")}
              >
                <Eye className="w-4 h-4" />
              </Button>
            </div>
          );
        })}
      </div>
    </Card>
  );
}
