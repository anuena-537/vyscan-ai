import { Card } from "@/components/ui/card";
import { LucideIcon } from "lucide-react";
import { cn } from "@/lib/utils";

interface StatsCardProps {
  icon: LucideIcon;
  title: string;
  value: string;
  trend: string;
  trendUp: boolean;
  color?: "primary" | "destructive" | "warning" | "info";
}

export default function StatsCard({ icon: Icon, title, value, trend, trendUp, color = "primary" }: StatsCardProps) {
  const colorClasses = {
    primary: "bg-primary/10 text-primary",
    destructive: "bg-destructive/10 text-destructive",
    warning: "bg-warning/10 text-warning",
    info: "bg-info/10 text-info",
  };

  return (
    <Card className="p-6 shadow-soft hover:shadow-medium transition-all duration-300 border-border/50">
      <div className="flex items-start justify-between mb-4">
        <div className={cn("w-12 h-12 rounded-xl flex items-center justify-center", colorClasses[color])}>
          <Icon className="w-6 h-6" />
        </div>
        <span className={cn("text-xs font-medium px-2 py-1 rounded-full", trendUp ? "bg-success/10 text-success" : "bg-muted text-muted-foreground")}>
          {trend}
        </span>
      </div>
      <div>
        <p className="text-sm text-muted-foreground mb-1">{title}</p>
        <p className="text-3xl font-bold">{value}</p>
      </div>
    </Card>
  );
}
