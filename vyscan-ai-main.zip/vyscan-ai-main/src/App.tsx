import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Index from "./pages/Index";
import Auth from "./pages/Auth";
import Dashboard from "./pages/Dashboard";
import PassportScan from "./pages/PassportScan";
import VisaScan from "./pages/VisaScan";
import BiometricVerification from "./pages/BiometricVerification";
import WatchlistCheck from "./pages/WatchlistCheck";
import BusinessDocScan from "./pages/BusinessDocScan";
import ScanHistory from "./pages/ScanHistory";
import Settings from "./pages/Settings";
import AuditLog from "./pages/AuditLog";
import TeamCollaboration from "./pages/TeamCollaboration";
import Notifications from "./pages/Notifications";
import Statistics from "./pages/Statistics";
import ScanMethods from "./pages/ScanMethods";
import NotFound from "./pages/NotFound";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<Auth />} />
          <Route path="/dashboard" element={<Dashboard />} />
          <Route path="/scan/passport" element={<PassportScan />} />
          <Route path="/scan/visa" element={<VisaScan />} />
          <Route path="/scan/business" element={<BusinessDocScan />} />
          <Route path="/scan/methods" element={<ScanMethods />} />
          <Route path="/biometric" element={<BiometricVerification />} />
          <Route path="/watchlist" element={<WatchlistCheck />} />
          <Route path="/scan-history" element={<ScanHistory />} />
          <Route path="/settings" element={<Settings />} />
          <Route path="/audit-log" element={<AuditLog />} />
          <Route path="/team-collaboration" element={<TeamCollaboration />} />
          <Route path="/notifications" element={<Notifications />} />
          <Route path="/statistics" element={<Statistics />} />
          {/* ADD ALL CUSTOM ROUTES ABOVE THE CATCH-ALL "*" ROUTE */}
          <Route path="*" element={<NotFound />} />
        </Routes>
      </BrowserRouter>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
