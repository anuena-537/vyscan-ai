import "https://deno.land/x/xhr@0.1.0/mod.ts";
import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { imageData, documentType } = await req.json();
    
    if (!imageData || !documentType) {
      return new Response(
        JSON.stringify({ error: 'Missing imageData or documentType' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const LOVABLE_API_KEY = Deno.env.get('LOVABLE_API_KEY');
    if (!LOVABLE_API_KEY) {
      console.error('LOVABLE_API_KEY not configured');
      return new Response(
        JSON.stringify({ error: 'AI service not configured' }),
        { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Parse data URL to extract base64 data and mime type
    let base64Data = imageData;
    let mimeType = 'image/jpeg';
    
    if (imageData.startsWith('data:')) {
      const matches = imageData.match(/^data:([^;]+);base64,(.+)$/);
      if (matches) {
        mimeType = matches[1];
        base64Data = matches[2];
      }
    }

    const systemPrompts: Record<string, string> = {
      passport: `You are an expert passport verification AI. Analyze the passport image and extract:
- Document number
- Full name
- Nationality
- Date of birth
- Expiry date
- Issue date
- Fraud score (0-100, where 0 is authentic and 100 is fraudulent)
- Security features status (MRZ verification, photo quality, hologram presence, microprinting)
- Any warnings or concerns

CRITICAL: If the document appears to be fake, forged, tampered, or suspicious:
- Set fraudScore between 70-100 (higher = more suspicious)
- Set all extracted data fields to null
- Add warning "SUSPECTED FAKE DOCUMENT - REQUIRES MANUAL INSPECTION" as the first warning
- List specific reasons for suspicion in additional warnings

Return ONLY valid JSON with this structure:
{
  "fraudScore": number,
  "documentNumber": string | null,
  "fullName": string | null,
  "nationality": string | null,
  "dateOfBirth": string | null,
  "expiryDate": string | null,
  "issueDate": string | null,
  "securityFeatures": [
    {"name": string, "status": "pass" | "fail" | "warning", "confidence": number}
  ],
  "warnings": string[]
}`,
      visa: `You are an expert visa verification AI. Analyze the visa image and extract:
- Visa type
- Visa number
- Country
- Valid from date
- Valid until date
- Fraud score (0-100, where 0 is authentic and 100 is fraudulent)
- Security features status
- Any warnings

CRITICAL: If the visa appears to be fake, forged, tampered, or suspicious:
- Set fraudScore between 70-100 (higher = more suspicious)
- Set all extracted data fields to null
- Add warning "SUSPECTED FAKE DOCUMENT - REQUIRES MANUAL INSPECTION" as the first warning
- List specific reasons for suspicion in additional warnings

Return ONLY valid JSON with this structure:
{
  "fraudScore": number,
  "visaType": string | null,
  "visaNumber": string | null,
  "country": string | null,
  "validFrom": string | null,
  "validUntil": string | null,
  "securityFeatures": [
    {"name": string, "status": "pass" | "fail" | "warning", "confidence": number}
  ],
  "warnings": string[]
}`,
      boarding: `You are an expert boarding pass verification AI. Analyze the boarding pass and extract:
- Passenger name
- Flight number
- Departure city
- Arrival city
- Departure date and time
- Seat number
- Tamper score (0-100, where 0 is authentic and 100 is tampered)
- Any concerns

CRITICAL: If the boarding pass appears to be fake, forged, tampered, or suspicious:
- Set tamperScore between 70-100 (higher = more suspicious)
- Set all extracted data fields to null
- Add warning "SUSPECTED FAKE DOCUMENT - REQUIRES MANUAL INSPECTION" as the first warning
- List specific reasons for suspicion in additional warnings

Return ONLY valid JSON with this structure:
{
  "tamperScore": number,
  "passengerName": string | null,
  "flightNumber": string | null,
  "departure": string | null,
  "arrival": string | null,
  "date": string | null,
  "time": string | null,
  "seat": string | null,
  "warnings": string[]
}`,
      authorization: `You are an expert authorization letter verification AI. Analyze the document and extract:
- Authorized person
- Authorizer name
- Purpose
- Valid from date
- Valid until date
- Tamper score (0-100, where 0 is authentic and 100 is tampered)
- Any concerns

CRITICAL: If the document appears to be fake, forged, tampered, or suspicious:
- Set tamperScore between 70-100 (higher = more suspicious)
- Set all extracted data fields to null
- Add warning "SUSPECTED FAKE DOCUMENT - REQUIRES MANUAL INSPECTION" as the first warning
- List specific reasons for suspicion in additional warnings

Return ONLY valid JSON with this structure:
{
  "tamperScore": number,
  "authorizedPerson": string | null,
  "authorizerName": string | null,
  "purpose": string | null,
  "validFrom": string | null,
  "validUntil": string | null,
  "warnings": string[]
}`,
      invitation: `You are an expert invitation letter verification AI. Analyze the invitation and extract:
- Guest name
- Host name
- Event purpose
- Event date
- Venue
- Tamper score (0-100, where 0 is authentic and 100 is tampered)
- Any concerns

CRITICAL: If the document appears to be fake, forged, tampered, or suspicious:
- Set tamperScore between 70-100 (higher = more suspicious)
- Set all extracted data fields to null
- Add warning "SUSPECTED FAKE DOCUMENT - REQUIRES MANUAL INSPECTION" as the first warning
- List specific reasons for suspicion in additional warnings

Return ONLY valid JSON with this structure:
{
  "tamperScore": number,
  "guestName": string | null,
  "hostName": string | null,
  "purpose": string | null,
  "eventDate": string | null,
  "venue": string | null,
  "warnings": string[]
}`,
      biometric: `You are an expert facial biometric verification AI. Compare the document photo with the live photo and provide:
- Match confidence score (0-100)
- Face similarity analysis
- Any concerns about photo quality or manipulation

Return ONLY valid JSON with this structure:
{
  "matchScore": number,
  "similarity": string,
  "warnings": string[]
}`
    };

    const systemPrompt = systemPrompts[documentType] || systemPrompts.passport;

    console.log(`Analyzing ${documentType} document with Gemini...`);

    // Retry logic for temporary gateway issues
    let response;
    let lastError;
    const maxRetries = 3;
    
    for (let attempt = 1; attempt <= maxRetries; attempt++) {
      try {
        response = await fetch('https://ai.gateway.lovable.dev/v1/chat/completions', {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${LOVABLE_API_KEY}`,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            model: 'google/gemini-2.5-flash',
            messages: [
              { role: 'system', content: systemPrompt },
              { 
                role: 'user', 
                content: [
                  { type: 'text', text: 'Analyze this document and provide the verification results in JSON format.' },
                  { 
                    type: 'image_url', 
                    image_url: { 
                      url: `data:${mimeType};base64,${base64Data}` 
                    } 
                  }
                ]
              }
            ],
          }),
        });

        if (response.ok) {
          break; // Success, exit retry loop
        }
        
        lastError = await response.text();
        console.error(`AI API error (attempt ${attempt}/${maxRetries}):`, response.status, lastError.substring(0, 200));
        
        // If it's a 500 error and we have retries left, wait and retry
        if (response.status === 500 && attempt < maxRetries) {
          const waitTime = Math.pow(2, attempt) * 1000; // Exponential backoff
          console.log(`Retrying in ${waitTime}ms...`);
          await new Promise(resolve => setTimeout(resolve, waitTime));
        } else {
          // Non-retryable error or last attempt
          return new Response(
            JSON.stringify({ 
              error: 'AI service temporarily unavailable. Please try again in a few moments.',
              technical_details: response.status === 500 ? 'Gateway timeout' : lastError.substring(0, 200)
            }),
            { status: 503, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
          );
        }
      } catch (fetchError) {
        lastError = fetchError instanceof Error ? fetchError.message : String(fetchError);
        console.error(`Network error (attempt ${attempt}/${maxRetries}):`, lastError);
        
        if (attempt < maxRetries) {
          const waitTime = Math.pow(2, attempt) * 1000;
          await new Promise(resolve => setTimeout(resolve, waitTime));
        } else {
          return new Response(
            JSON.stringify({ 
              error: 'Network error connecting to AI service. Please check your connection and try again.',
              technical_details: lastError
            }),
            { status: 503, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
          );
        }
      }
    }

    if (!response) {
      return new Response(
        JSON.stringify({ error: 'Failed to connect to AI service after multiple attempts' }),
        { status: 503, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const aiResponse = await response.json();
    const content = aiResponse.choices?.[0]?.message?.content;

    if (!content) {
      console.error('No content in AI response, attempting OCR fallback...');
      
      try {
        const ocrResponse = await fetch('https://ai.gateway.lovable.dev/v1/chat/completions', {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${LOVABLE_API_KEY}`,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            model: 'google/gemini-2.5-flash-lite',
            messages: [
              { 
                role: 'system', 
                content: 'Extract all visible text from this document. Return only the raw text content, no analysis.' 
              },
              { 
                role: 'user', 
                content: [
                  { type: 'text', text: 'Extract all text from this image.' },
                  { 
                    type: 'image_url', 
                    image_url: { 
                      url: `data:${mimeType};base64,${base64Data}` 
                    } 
                  }
                ]
              }
            ],
          }),
        });

        if (ocrResponse.ok) {
          const ocrResult = await ocrResponse.json();
          const extractedText = ocrResult.choices?.[0]?.message?.content || '';
          
          console.log('OCR fallback successful');
          return new Response(
            JSON.stringify({ 
              ocrFallback: true,
              extractedText,
              message: 'AI analysis unavailable. Basic text extraction performed.',
              warnings: ['Document requires manual review - automated analysis unavailable']
            }),
            { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
          );
        }
      } catch (ocrError) {
        console.error('OCR fallback failed:', ocrError);
      }
      
      return new Response(
        JSON.stringify({ 
          error: 'AI service temporarily unavailable',
          message: 'Please try again in a few moments'
        }),
        { status: 503, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Extract JSON from the response (handle markdown code blocks)
    let jsonResult;
    try {
      const jsonMatch = content.match(/```json\s*([\s\S]*?)\s*```/) || content.match(/\{[\s\S]*\}/);
      const jsonString = jsonMatch ? (jsonMatch[1] || jsonMatch[0]) : content;
      jsonResult = JSON.parse(jsonString.trim());
    } catch (parseError) {
      console.error('Failed to parse AI response:', content);
      return new Response(
        JSON.stringify({ error: 'Failed to parse analysis results', rawContent: content }),
        { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    console.log('Analysis complete:', jsonResult);

    return new Response(
      JSON.stringify(jsonResult),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error) {
    console.error('Error in analyze-document function:', error);
    return new Response(
      JSON.stringify({ error: error instanceof Error ? error.message : 'Unknown error' }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});
